# Sources of the binaries in this bundle

The binaries in this bundle were built from, or copied unmodified out of, the exact sources listed below,
per platform. `LICENSES/MANIFEST.tsv` maps every binary to its components, and `LICENSES/<component>/` holds
each component's license text, taken from that component's own source tree, from the Ubuntu 18.04 build
image (`/usr/share/doc/<package>/copyright` and the `/usr/share/common-licenses/` texts it refers to) or from
the Homebrew keg the library was copied from.

The complete corresponding source code of every component under the GNU GPL or LGPL is available at the
locations below: upstream tags and commits, Ubuntu source packages (`apt-get source <package>=<version>` on
Ubuntu 18.04, or Launchpad) and Homebrew formula source tarballs. Components that were modified for this
build say so and list the exact changes (see also `LICENSES/<component>/MODIFICATIONS`).

The build scripts are in https://github.com/electron-userland/electron-builder-binaries/tree/master/packages/appimage.

## darwin/arm64

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- Homebrew `libpng` 1.6.58 (formula license: "libpng-2.0"): https://downloads.sourceforge.net/project/libpng/libpng16/1.6.58/libpng-1.6.58.tar.xz
- Homebrew `libtiff` 4.7.2 (formula license: "libtiff"): https://download.osgeo.org/libtiff/tiff-4.7.2.tar.gz
- Homebrew `little-cms2` 2.19.1 (formula license: "MIT"): https://downloads.sourceforge.net/project/lcms/lcms/2.19.1/lcms2-2.19.1.tar.gz
- Homebrew `lzo` 2.10 (formula license: "GPL-2.0-or-later"): https://www.oberhumer.com/opensource/lzo/download/lzo-2.10.tar.gz
- Homebrew `lz4` 1.10.0 (formula license: "BSD-2-Clause"): https://github.com/lz4/lz4/archive/refs/tags/v1.10.0.tar.gz
- Homebrew `xz` 5.8.3 (formula license: all_of: [): https://github.com/tukaani-project/xz/releases/download/v5.8.3/xz-5.8.3.tar.gz
- Homebrew `webp` 1.6.0 (formula license: "BSD-3-Clause"): https://storage.googleapis.com/downloads.webmproject.org/releases/webp/libwebp-1.6.0.tar.gz
- Homebrew `zstd` 1.5.7_1 (formula license: all_of: [): https://github.com/facebook/zstd/archive/refs/tags/v1.5.7.tar.gz
- Homebrew `jpeg-turbo` 3.2.0 (formula license: all_of: [): https://github.com/libjpeg-turbo/libjpeg-turbo/releases/download/3.2.0/libjpeg-turbo-3.2.0.tar.gz

## darwin/x64

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- Homebrew `libpng` 1.6.58 (formula license: "libpng-2.0"): https://downloads.sourceforge.net/project/libpng/libpng16/1.6.58/libpng-1.6.58.tar.xz
- Homebrew `libtiff` 4.7.2 (formula license: "libtiff"): https://download.osgeo.org/libtiff/tiff-4.7.2.tar.gz
- Homebrew `little-cms2` 2.19 (formula license: "MIT"): https://downloads.sourceforge.net/project/lcms/lcms/2.19/lcms2-2.19.tar.gz
- Homebrew `lzo` 2.10 (formula license: "GPL-2.0-or-later"): https://www.oberhumer.com/opensource/lzo/download/lzo-2.10.tar.gz
- Homebrew `lz4` 1.10.0 (formula license: "BSD-2-Clause"): https://github.com/lz4/lz4/archive/refs/tags/v1.10.0.tar.gz
- Homebrew `xz` 5.8.3 (formula license: all_of: [): https://github.com/tukaani-project/xz/releases/download/v5.8.3/xz-5.8.3.tar.gz
- Homebrew `webp` 1.6.0 (formula license: "BSD-3-Clause"): https://storage.googleapis.com/downloads.webmproject.org/releases/webp/libwebp-1.6.0.tar.gz
- Homebrew `zstd` 1.5.7_1 (formula license: all_of: [): https://github.com/facebook/zstd/archive/refs/tags/v1.5.7.tar.gz
- Homebrew `jpeg-turbo` 3.2.0 (formula license: all_of: [): https://github.com/libjpeg-turbo/libjpeg-turbo/releases/download/3.2.0/libjpeg-turbo-3.2.0.tar.gz

## linux/arm32

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- `zlib1g` 1:1.2.11.dfsg-0ubuntu2.2 (Ubuntu 18.04 package; source package `zlib` 1:1.2.11.dfsg-0ubuntu2.2: https://launchpad.net/ubuntu/+source/zlib/1:1.2.11.dfsg-0ubuntu2.2)
- `liblzo2-2` 2.08-1.2 (Ubuntu 18.04 package; source package `lzo2` 2.08-1.2: https://launchpad.net/ubuntu/+source/lzo2/2.08-1.2)
- `liblz4-1` 0.0~r131-2ubuntu3.1 (Ubuntu 18.04 package; source package `lz4` 0.0~r131-2ubuntu3.1: https://launchpad.net/ubuntu/+source/lz4/0.0~r131-2ubuntu3.1)
- `liblzma5` 5.2.2-1.3ubuntu0.1 (Ubuntu 18.04 package; source package `xz-utils` 5.2.2-1.3ubuntu0.1: https://launchpad.net/ubuntu/+source/xz-utils/5.2.2-1.3ubuntu0.1)
- `libpng16-16` 1.6.34-1ubuntu0.18.04.2 (Ubuntu 18.04 package; source package `libpng1.6` 1.6.34-1ubuntu0.18.04.2: https://launchpad.net/ubuntu/+source/libpng1.6/1.6.34-1ubuntu0.18.04.2)
- `libtiff5` 4.0.9-5ubuntu0.10 (Ubuntu 18.04 package; source package `tiff` 4.0.9-5ubuntu0.10: https://launchpad.net/ubuntu/+source/tiff/4.0.9-5ubuntu0.10)
- `liblcms2-2` 2.9-1ubuntu0.1 (Ubuntu 18.04 package; source package `lcms2` 2.9-1ubuntu0.1: https://launchpad.net/ubuntu/+source/lcms2/2.9-1ubuntu0.1)
- `libjbig0` 2.1-3.1ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `jbigkit` 2.1-3.1ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/jbigkit/2.1-3.1ubuntu0.18.04.1)
- `libjpeg-turbo8` 1.5.2-0ubuntu5.18.04.6 (Ubuntu 18.04 package; source package `libjpeg-turbo` 1.5.2-0ubuntu5.18.04.6: https://launchpad.net/ubuntu/+source/libjpeg-turbo/1.5.2-0ubuntu5.18.04.6)
- `libxss1` 1:1.2.2-1 (Ubuntu 18.04 package; source package `libxss` 1:1.2.2-1: https://launchpad.net/ubuntu/+source/libxss/1:1.2.2-1)
- `libxtst6` 2:1.2.3-1 (Ubuntu 18.04 package; source package `libxtst` 2:1.2.3-1: https://launchpad.net/ubuntu/+source/libxtst/2:1.2.3-1)
- `libnotify4` 0.7.7-3ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `libnotify` 0.7.7-3ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/libnotify/0.7.7-3ubuntu0.18.04.1)
- `libgconf-2-4` 3.2.6-4ubuntu1 (Ubuntu 18.04 package; source package `gconf` 3.2.6-4ubuntu1: https://launchpad.net/ubuntu/+source/gconf/3.2.6-4ubuntu1)
- `libappindicator3-1` 12.10.1+18.04.20200408.1-0ubuntu1 (Ubuntu 18.04 package; source package `libappindicator` 12.10.1+18.04.20200408.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libappindicator/12.10.1+18.04.20200408.1-0ubuntu1)
- `libindicator3-7` 16.10.0+18.04.20180321.1-0ubuntu1 (Ubuntu 18.04 package; source package `libindicator` 16.10.0+18.04.20180321.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libindicator/16.10.0+18.04.20180321.1-0ubuntu1)

## linux/arm64

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- `zlib1g` 1:1.2.11.dfsg-0ubuntu2.2 (Ubuntu 18.04 package; source package `zlib` 1:1.2.11.dfsg-0ubuntu2.2: https://launchpad.net/ubuntu/+source/zlib/1:1.2.11.dfsg-0ubuntu2.2)
- `liblzo2-2` 2.08-1.2 (Ubuntu 18.04 package; source package `lzo2` 2.08-1.2: https://launchpad.net/ubuntu/+source/lzo2/2.08-1.2)
- `liblz4-1` 0.0~r131-2ubuntu3.1 (Ubuntu 18.04 package; source package `lz4` 0.0~r131-2ubuntu3.1: https://launchpad.net/ubuntu/+source/lz4/0.0~r131-2ubuntu3.1)
- `liblzma5` 5.2.2-1.3ubuntu0.1 (Ubuntu 18.04 package; source package `xz-utils` 5.2.2-1.3ubuntu0.1: https://launchpad.net/ubuntu/+source/xz-utils/5.2.2-1.3ubuntu0.1)
- `libpng16-16` 1.6.34-1ubuntu0.18.04.2 (Ubuntu 18.04 package; source package `libpng1.6` 1.6.34-1ubuntu0.18.04.2: https://launchpad.net/ubuntu/+source/libpng1.6/1.6.34-1ubuntu0.18.04.2)
- `libtiff5` 4.0.9-5ubuntu0.10 (Ubuntu 18.04 package; source package `tiff` 4.0.9-5ubuntu0.10: https://launchpad.net/ubuntu/+source/tiff/4.0.9-5ubuntu0.10)
- `liblcms2-2` 2.9-1ubuntu0.1 (Ubuntu 18.04 package; source package `lcms2` 2.9-1ubuntu0.1: https://launchpad.net/ubuntu/+source/lcms2/2.9-1ubuntu0.1)
- `libjbig0` 2.1-3.1ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `jbigkit` 2.1-3.1ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/jbigkit/2.1-3.1ubuntu0.18.04.1)
- `libjpeg-turbo8` 1.5.2-0ubuntu5.18.04.6 (Ubuntu 18.04 package; source package `libjpeg-turbo` 1.5.2-0ubuntu5.18.04.6: https://launchpad.net/ubuntu/+source/libjpeg-turbo/1.5.2-0ubuntu5.18.04.6)
- `libxss1` 1:1.2.2-1 (Ubuntu 18.04 package; source package `libxss` 1:1.2.2-1: https://launchpad.net/ubuntu/+source/libxss/1:1.2.2-1)
- `libxtst6` 2:1.2.3-1 (Ubuntu 18.04 package; source package `libxtst` 2:1.2.3-1: https://launchpad.net/ubuntu/+source/libxtst/2:1.2.3-1)
- `libnotify4` 0.7.7-3ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `libnotify` 0.7.7-3ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/libnotify/0.7.7-3ubuntu0.18.04.1)
- `libgconf-2-4` 3.2.6-4ubuntu1 (Ubuntu 18.04 package; source package `gconf` 3.2.6-4ubuntu1: https://launchpad.net/ubuntu/+source/gconf/3.2.6-4ubuntu1)
- `libappindicator3-1` 12.10.1+18.04.20200408.1-0ubuntu1 (Ubuntu 18.04 package; source package `libappindicator` 12.10.1+18.04.20200408.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libappindicator/12.10.1+18.04.20200408.1-0ubuntu1)
- `libindicator3-7` 16.10.0+18.04.20180321.1-0ubuntu1 (Ubuntu 18.04 package; source package `libindicator` 16.10.0+18.04.20180321.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libindicator/16.10.0+18.04.20180321.1-0ubuntu1)

## linux/ia32

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- `zlib1g` 1:1.2.11.dfsg-0ubuntu2.2 (Ubuntu 18.04 package; source package `zlib` 1:1.2.11.dfsg-0ubuntu2.2: https://launchpad.net/ubuntu/+source/zlib/1:1.2.11.dfsg-0ubuntu2.2)
- `liblzo2-2` 2.08-1.2 (Ubuntu 18.04 package; source package `lzo2` 2.08-1.2: https://launchpad.net/ubuntu/+source/lzo2/2.08-1.2)
- `liblz4-1` 0.0~r131-2ubuntu3.1 (Ubuntu 18.04 package; source package `lz4` 0.0~r131-2ubuntu3.1: https://launchpad.net/ubuntu/+source/lz4/0.0~r131-2ubuntu3.1)
- `liblzma5` 5.2.2-1.3ubuntu0.1 (Ubuntu 18.04 package; source package `xz-utils` 5.2.2-1.3ubuntu0.1: https://launchpad.net/ubuntu/+source/xz-utils/5.2.2-1.3ubuntu0.1)
- `libpng16-16` 1.6.34-1ubuntu0.18.04.2 (Ubuntu 18.04 package; source package `libpng1.6` 1.6.34-1ubuntu0.18.04.2: https://launchpad.net/ubuntu/+source/libpng1.6/1.6.34-1ubuntu0.18.04.2)
- `libtiff5` 4.0.9-5ubuntu0.10 (Ubuntu 18.04 package; source package `tiff` 4.0.9-5ubuntu0.10: https://launchpad.net/ubuntu/+source/tiff/4.0.9-5ubuntu0.10)
- `liblcms2-2` 2.9-1ubuntu0.1 (Ubuntu 18.04 package; source package `lcms2` 2.9-1ubuntu0.1: https://launchpad.net/ubuntu/+source/lcms2/2.9-1ubuntu0.1)
- `libjbig0` 2.1-3.1ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `jbigkit` 2.1-3.1ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/jbigkit/2.1-3.1ubuntu0.18.04.1)
- `libjpeg-turbo8` 1.5.2-0ubuntu5.18.04.6 (Ubuntu 18.04 package; source package `libjpeg-turbo` 1.5.2-0ubuntu5.18.04.6: https://launchpad.net/ubuntu/+source/libjpeg-turbo/1.5.2-0ubuntu5.18.04.6)
- `libxss1` 1:1.2.2-1 (Ubuntu 18.04 package; source package `libxss` 1:1.2.2-1: https://launchpad.net/ubuntu/+source/libxss/1:1.2.2-1)
- `libxtst6` 2:1.2.3-1 (Ubuntu 18.04 package; source package `libxtst` 2:1.2.3-1: https://launchpad.net/ubuntu/+source/libxtst/2:1.2.3-1)
- `libnotify4` 0.7.7-3ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `libnotify` 0.7.7-3ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/libnotify/0.7.7-3ubuntu0.18.04.1)
- `libgconf-2-4` 3.2.6-4ubuntu1 (Ubuntu 18.04 package; source package `gconf` 3.2.6-4ubuntu1: https://launchpad.net/ubuntu/+source/gconf/3.2.6-4ubuntu1)
- `libappindicator1` 12.10.1+18.04.20180322.1-0ubuntu1 (Ubuntu 18.04 package; source package `libappindicator` 12.10.1+18.04.20180322.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libappindicator/12.10.1+18.04.20180322.1-0ubuntu1)
- `libindicator7` 16.10.0+18.04.20180321.1-0ubuntu1 (Ubuntu 18.04 package; source package `libindicator` 16.10.0+18.04.20180321.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libindicator/16.10.0+18.04.20180321.1-0ubuntu1)

## linux/x64

- squashfs-tools 4.7.5, commit 708c59ae80853b0845017c33b42e56061cc546cd (https://github.com/plougher/squashfs-tools), **modified**: upstream commits f88f4a659d6ab432a57e90fe2f6191149c6b343f c96f0ecd47aabedd489dc0f8241894c8d068ce4f 58f659e105c6f42343805b9204ecd6657c482dc2 cherry-picked on top (LICENSES/squashfs-tools/MODIFICATIONS)
- desktop-file-utils 0.28, commit bc403b7e9ea4847b1590c41eb1581aa3f1d24b36 (https://gitlab.freedesktop.org/xdg/desktop-file-utils)
- zstd 1.5.7: https://github.com/facebook/zstd/releases/download/v1.5.7/zstd-1.5.7.tar.gz (sha256 eb33e51f49a15e023950cd7825ca74a4a2b43db8354825ac24fc1b7ee09e6fa3), linked statically into mksquashfs and unsquashfs
- OpenJPEG 2.5.4: https://github.com/uclouvain/openjpeg/archive/v2.5.4.tar.gz (sha256 a695fbe19c0165f295a8531b1e4e855cd94d0875d2f88ec4b61080677e27188a)
- `zlib1g` 1:1.2.11.dfsg-0ubuntu2.2 (Ubuntu 18.04 package; source package `zlib` 1:1.2.11.dfsg-0ubuntu2.2: https://launchpad.net/ubuntu/+source/zlib/1:1.2.11.dfsg-0ubuntu2.2)
- `liblzo2-2` 2.08-1.2 (Ubuntu 18.04 package; source package `lzo2` 2.08-1.2: https://launchpad.net/ubuntu/+source/lzo2/2.08-1.2)
- `liblz4-1` 0.0~r131-2ubuntu3.1 (Ubuntu 18.04 package; source package `lz4` 0.0~r131-2ubuntu3.1: https://launchpad.net/ubuntu/+source/lz4/0.0~r131-2ubuntu3.1)
- `liblzma5` 5.2.2-1.3ubuntu0.1 (Ubuntu 18.04 package; source package `xz-utils` 5.2.2-1.3ubuntu0.1: https://launchpad.net/ubuntu/+source/xz-utils/5.2.2-1.3ubuntu0.1)
- `libpng16-16` 1.6.34-1ubuntu0.18.04.2 (Ubuntu 18.04 package; source package `libpng1.6` 1.6.34-1ubuntu0.18.04.2: https://launchpad.net/ubuntu/+source/libpng1.6/1.6.34-1ubuntu0.18.04.2)
- `libtiff5` 4.0.9-5ubuntu0.10 (Ubuntu 18.04 package; source package `tiff` 4.0.9-5ubuntu0.10: https://launchpad.net/ubuntu/+source/tiff/4.0.9-5ubuntu0.10)
- `liblcms2-2` 2.9-1ubuntu0.1 (Ubuntu 18.04 package; source package `lcms2` 2.9-1ubuntu0.1: https://launchpad.net/ubuntu/+source/lcms2/2.9-1ubuntu0.1)
- `libjbig0` 2.1-3.1ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `jbigkit` 2.1-3.1ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/jbigkit/2.1-3.1ubuntu0.18.04.1)
- `libjpeg-turbo8` 1.5.2-0ubuntu5.18.04.6 (Ubuntu 18.04 package; source package `libjpeg-turbo` 1.5.2-0ubuntu5.18.04.6: https://launchpad.net/ubuntu/+source/libjpeg-turbo/1.5.2-0ubuntu5.18.04.6)
- `libxss1` 1:1.2.2-1 (Ubuntu 18.04 package; source package `libxss` 1:1.2.2-1: https://launchpad.net/ubuntu/+source/libxss/1:1.2.2-1)
- `libxtst6` 2:1.2.3-1 (Ubuntu 18.04 package; source package `libxtst` 2:1.2.3-1: https://launchpad.net/ubuntu/+source/libxtst/2:1.2.3-1)
- `libnotify4` 0.7.7-3ubuntu0.18.04.1 (Ubuntu 18.04 package; source package `libnotify` 0.7.7-3ubuntu0.18.04.1: https://launchpad.net/ubuntu/+source/libnotify/0.7.7-3ubuntu0.18.04.1)
- `libgconf-2-4` 3.2.6-4ubuntu1 (Ubuntu 18.04 package; source package `gconf` 3.2.6-4ubuntu1: https://launchpad.net/ubuntu/+source/gconf/3.2.6-4ubuntu1)
- `libappindicator3-1` 12.10.1+18.04.20200408.1-0ubuntu1 (Ubuntu 18.04 package; source package `libappindicator` 12.10.1+18.04.20200408.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libappindicator/12.10.1+18.04.20200408.1-0ubuntu1)
- `libindicator3-7` 16.10.0+18.04.20180321.1-0ubuntu1 (Ubuntu 18.04 package; source package `libindicator` 16.10.0+18.04.20180321.1-0ubuntu1: https://launchpad.net/ubuntu/+source/libindicator/16.10.0+18.04.20180321.1-0ubuntu1)

## runtimes/ (AppImage type2-runtime 20251108)

- type2-runtime 20251108: unmodified release binaries from https://github.com/AppImage/type2-runtime/releases/tag/20251108 (SHA256s and signing key in runtimes/VERSION.txt); source: https://github.com/AppImage/type2-runtime/tree/20251108
- libfuse 3.15.0, statically linked into the runtime (LGPL-2.1): https://github.com/libfuse/libfuse/releases/download/fuse-3.15.0/fuse-3.15.0.tar.xz, **modified** by type2-runtime's patches/libfuse/mount.c.diff (https://github.com/AppImage/type2-runtime/blob/20251108/patches/libfuse/mount.c.diff); the runtime's complete source and build scripts are at the type2-runtime tag above
- squashfuse 0.5.2, statically linked into the runtime: https://github.com/vasi/squashfuse/archive/0.5.2.tar.gz
- musl 1.2.5, zstd 1.5.6, zlib 1.3.1 and mimalloc 2.1.7, statically linked into the runtime: Alpine Linux 3.21 packages (https://pkgs.alpinelinux.org/packages?branch=v3.21)
