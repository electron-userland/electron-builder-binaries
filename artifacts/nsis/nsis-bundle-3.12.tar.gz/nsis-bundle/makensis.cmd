@echo off
setlocal ENABLEEXTENSIONS

REM =============================================================
REM NSIS Windows CMD Entrypoint
REM =============================================================
REM Delegates to makensis.ps1 via pwsh so that makensisw.exe
REM (GUI subsystem) can be run hidden and auto-closed after compile.
REM =============================================================

set SCRIPT_DIR=%~dp0
set SCRIPT_DIR=%SCRIPT_DIR:~0,-1%

pwsh -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%\makensis.ps1" %*
exit /b %ERRORLEVEL%
