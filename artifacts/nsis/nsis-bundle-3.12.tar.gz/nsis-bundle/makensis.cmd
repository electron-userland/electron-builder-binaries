@echo off
setlocal ENABLEEXTENSIONS

REM =============================================================
REM NSIS Windows CMD Entrypoint
REM =============================================================
REM Sets NSISDIR and forwards all arguments to makensis.exe
REM =============================================================

REM Determine directory of this script
set SCRIPT_DIR=%~dp0
REM Remove trailing backslash
set SCRIPT_DIR=%SCRIPT_DIR:~0,-1%

REM Set NSISDIR if not already defined
if not defined NSISDIR (
  set NSISDIR=%SCRIPT_DIR%\windows
)

REM Execute makensis.exe with all passed arguments
"%NSISDIR%\makensis.exe" %*
set EXITCODE=%ERRORLEVEL%

endlocal & exit /b %EXITCODE%
