# Third-party NSIS plugins

NSIS itself, including the plugins built from its source, is covered by `LICENSE` (NSIS's `COPYING`).
Each third-party plugin below keeps its own license; its license files are in `LICENSES/<plugin>/`.
`plugin-dlls.tsv` maps every DLL in `windows/Plugins` to the plugin it came from.

## INetC

- Source: https://github.com/DigitalMediaServer/NSIS-INetC-plugin/releases/download/v1.0.5.7/INetC.zip
- SHA256: b01077e56ebb19c005b45d40f837958ca6a92f51a5a937dc1bb497c7c7f2aa93
- License files:
  - LICENSE.md
- DLLs:
  - x64-ansi/INetC.dll
  - x64-unicode/INetC.dll
  - x86-ansi/INetC.dll
  - x86-unicode/INetC.dll

## StdUtils

- Source: https://github.com/lordmulder/stdutils/releases/download/1.14/StdUtils.2018-10-27.zip
- SHA256: 3ffe893dc7477fdb1cac551a86ae017509e1f2d0ebdc7185fd0fbaf20870688c
- License files:
  - LGPL.txt
  - LGPL_CLARIFICATION.txt
  - ReadMe.txt
  - src/blake2/COPYING.txt
  - src/rhash/COPYING.txt
- DLLs:
  - x86-ansi/StdUtils.dll
  - x86-unicode/StdUtils.dll

## SpiderBanner

- Source: https://nsis.sourceforge.io/mediawiki/images/4/4c/SpiderBanner_plugin.zip
- SHA256: 45c79a024e5122834a3473a87649757bc11958a11602a3ce2d9f7ce006f0e2b7
- License files:
  - NOTICE-plugin-api.txt
- DLLs:
  - x86-ansi/SpiderBanner.dll
  - x86-unicode/SpiderBanner.dll

## NsProcess

- Source: https://nsis.sourceforge.io/mediawiki/images/1/18/NsProcess.zip
- SHA256: fc19fc66a5219a233570fafd5daeb0c9b85387b379f6df5ac8898159a57c5944
- License files:
  - NOTICE-plugin-api.txt
  - Readme.txt
- DLLs:
  - x86-ansi/nsProcess.dll
  - x86-unicode/nsProcess.dll
  - x86-unicode/nsProcessW.dll

## UAC

- Source: https://nsis.sourceforge.io/mediawiki/images/8/8f/UAC.zip
- SHA256: 20e3192af5598568887c16d88de59a52c2ce4a26e42c5fb8bee8105dcbbd1760
- License files:
  - License.txt
- DLLs:
  - x86-ansi/UAC.dll
  - x86-unicode/UAC.dll

## WinShell

- Source: https://nsis.sourceforge.io/mediawiki/images/5/54/WinShell.zip
- SHA256: 34e111f8aacf64c540d848fd06b9d6f3e2c10cb825ec9329a01d1141973e749b
- License files:
  - NOTICE-plugin-api.txt
- DLLs:
  - x86-ansi/WinShell.dll
  - x86-unicode/WinShell.dll

## EmbedHTML

- Source: https://nsis.sourceforge.io/mediawiki/images/7/7c/EmbedHTML.zip
- SHA256: f00732a93660fa71c8bfcac35e68242780262a46929274cb9182117094475a1a
- License files:
  - Docs/EmbedHTML/Readme.txt
- DLLs:
  - x64-ansi/EmbedHTML.dll
  - x64-unicode/EmbedHTML.dll
  - x86-ansi/EmbedHTML.dll
  - x86-unicode/EmbedHTML.dll

## Nsisunz

- Source: https://nsis.sourceforge.io/mediawiki/images/1/1c/Nsisunz.zip
- SHA256: 599029776df526def921ea178a6f66325b6f719772c38318e349a5c92a03afe9
- License files:
  - nsisunz/zlib/README
- DLLs:
  - x86-ansi/nsisunz.dll

## NSISunzU

- Source: https://nsis.sourceforge.io/mediawiki/images/5/5a/NSISunzU.zip
- SHA256: 8c2b7ad6984e3137e4c51c763ec64cbd36364e72838b85e14fa287dac976c46b
- License files:
  - NOTICE-plugin-api.txt
- DLLs:
  - x86-unicode/nsisunz.dll

## nsis7z

- Source: https://nsis.sourceforge.io/mediawiki/images/6/69/Nsis7z_19.00.7z
- SHA256: 6f2f3730049926f40442ee0c8b7d3e3dee7ace544d82467ff8059ea3f4201c58
- License files:
  - Contrib/nsis7z/DOC/License.txt
- DLLs:
  - x64-unicode/nsis7z.dll
  - x86-ansi/nsis7z.dll
  - x86-unicode/nsis7z.dll
