var UZIP;
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../../node_modules/.pnpm/@resvg+resvg-wasm@2.6.2/node_modules/@resvg/resvg-wasm/index.js
var require_resvg_wasm = __commonJS({
  "../../../node_modules/.pnpm/@resvg+resvg-wasm@2.6.2/node_modules/@resvg/resvg-wasm/index.js"(exports2, module2) {
    "use strict";
    var __defProp2 = Object.defineProperty;
    var __getOwnPropDesc2 = Object.getOwnPropertyDescriptor;
    var __getOwnPropNames2 = Object.getOwnPropertyNames;
    var __hasOwnProp2 = Object.prototype.hasOwnProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp2(target, name, { get: all[name], enumerable: true });
    };
    var __copyProps2 = (to, from, except, desc) => {
      if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames2(from))
          if (!__hasOwnProp2.call(to, key) && key !== except)
            __defProp2(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc2(from, key)) || desc.enumerable });
      }
      return to;
    };
    var __toCommonJS = (mod) => __copyProps2(__defProp2({}, "__esModule", { value: true }), mod);
    var wasm_binding_exports = {};
    __export(wasm_binding_exports, {
      Resvg: () => Resvg2,
      initWasm: () => initWasm
    });
    module2.exports = __toCommonJS(wasm_binding_exports);
    var wasm;
    var heap = new Array(128).fill(void 0);
    heap.push(void 0, null, true, false);
    var heap_next = heap.length;
    function addHeapObject(obj) {
      if (heap_next === heap.length)
        heap.push(heap.length + 1);
      const idx = heap_next;
      heap_next = heap[idx];
      heap[idx] = obj;
      return idx;
    }
    function getObject(idx) {
      return heap[idx];
    }
    function dropObject(idx) {
      if (idx < 132)
        return;
      heap[idx] = heap_next;
      heap_next = idx;
    }
    function takeObject(idx) {
      const ret = getObject(idx);
      dropObject(idx);
      return ret;
    }
    var WASM_VECTOR_LEN = 0;
    var cachedUint8Memory0 = null;
    function getUint8Memory0() {
      if (cachedUint8Memory0 === null || cachedUint8Memory0.byteLength === 0) {
        cachedUint8Memory0 = new Uint8Array(wasm.memory.buffer);
      }
      return cachedUint8Memory0;
    }
    var cachedTextEncoder = typeof TextEncoder !== "undefined" ? new TextEncoder("utf-8") : { encode: () => {
      throw Error("TextEncoder not available");
    } };
    var encodeString = typeof cachedTextEncoder.encodeInto === "function" ? function(arg, view) {
      return cachedTextEncoder.encodeInto(arg, view);
    } : function(arg, view) {
      const buf = cachedTextEncoder.encode(arg);
      view.set(buf);
      return {
        read: arg.length,
        written: buf.length
      };
    };
    function passStringToWasm0(arg, malloc, realloc) {
      if (realloc === void 0) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr2 = malloc(buf.length, 1) >>> 0;
        getUint8Memory0().subarray(ptr2, ptr2 + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr2;
      }
      let len = arg.length;
      let ptr = malloc(len, 1) >>> 0;
      const mem = getUint8Memory0();
      let offset = 0;
      for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 127)
          break;
        mem[ptr + offset] = code;
      }
      if (offset !== len) {
        if (offset !== 0) {
          arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);
        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
      }
      WASM_VECTOR_LEN = offset;
      return ptr;
    }
    function isLikeNone(x) {
      return x === void 0 || x === null;
    }
    var cachedInt32Memory0 = null;
    function getInt32Memory0() {
      if (cachedInt32Memory0 === null || cachedInt32Memory0.byteLength === 0) {
        cachedInt32Memory0 = new Int32Array(wasm.memory.buffer);
      }
      return cachedInt32Memory0;
    }
    var cachedTextDecoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }) : { decode: () => {
      throw Error("TextDecoder not available");
    } };
    if (typeof TextDecoder !== "undefined") {
      cachedTextDecoder.decode();
    }
    function getStringFromWasm0(ptr, len) {
      ptr = ptr >>> 0;
      return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
    }
    function _assertClass(instance, klass) {
      if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
      }
      return instance.ptr;
    }
    function handleError(f, args) {
      try {
        return f.apply(this, args);
      } catch (e) {
        wasm.__wbindgen_exn_store(addHeapObject(e));
      }
    }
    var BBoxFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_bbox_free(ptr >>> 0));
    var BBox = class _BBox {
      static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(_BBox.prototype);
        obj.__wbg_ptr = ptr;
        BBoxFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
      }
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BBoxFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_bbox_free(ptr);
      }
      /**
      * @returns {number}
      */
      get x() {
        const ret = wasm.__wbg_get_bbox_x(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set x(arg0) {
        wasm.__wbg_set_bbox_x(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get y() {
        const ret = wasm.__wbg_get_bbox_y(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set y(arg0) {
        wasm.__wbg_set_bbox_y(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get width() {
        const ret = wasm.__wbg_get_bbox_width(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set width(arg0) {
        wasm.__wbg_set_bbox_width(this.__wbg_ptr, arg0);
      }
      /**
      * @returns {number}
      */
      get height() {
        const ret = wasm.__wbg_get_bbox_height(this.__wbg_ptr);
        return ret;
      }
      /**
      * @param {number} arg0
      */
      set height(arg0) {
        wasm.__wbg_set_bbox_height(this.__wbg_ptr, arg0);
      }
    };
    var RenderedImageFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_renderedimage_free(ptr >>> 0));
    var RenderedImage = class _RenderedImage {
      static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(_RenderedImage.prototype);
        obj.__wbg_ptr = ptr;
        RenderedImageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
      }
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RenderedImageFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_renderedimage_free(ptr);
      }
      /**
      * Get the PNG width
      * @returns {number}
      */
      get width() {
        const ret = wasm.renderedimage_width(this.__wbg_ptr);
        return ret >>> 0;
      }
      /**
      * Get the PNG height
      * @returns {number}
      */
      get height() {
        const ret = wasm.renderedimage_height(this.__wbg_ptr);
        return ret >>> 0;
      }
      /**
      * Write the image data to Uint8Array
      * @returns {Uint8Array}
      */
      asPng() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.renderedimage_asPng(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return takeObject(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Get the RGBA pixels of the image
      * @returns {Uint8Array}
      */
      get pixels() {
        const ret = wasm.renderedimage_pixels(this.__wbg_ptr);
        return takeObject(ret);
      }
    };
    var ResvgFinalization = typeof FinalizationRegistry === "undefined" ? { register: () => {
    }, unregister: () => {
    } } : new FinalizationRegistry((ptr) => wasm.__wbg_resvg_free(ptr >>> 0));
    var Resvg = class {
      __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResvgFinalization.unregister(this);
        return ptr;
      }
      free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_resvg_free(ptr);
      }
      /**
      * @param {Uint8Array | string} svg
      * @param {string | undefined} [options]
      * @param {Array<any> | undefined} [custom_font_buffers]
      */
      constructor(svg, options, custom_font_buffers) {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          var ptr0 = isLikeNone(options) ? 0 : passStringToWasm0(options, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
          var len0 = WASM_VECTOR_LEN;
          wasm.resvg_new(retptr, addHeapObject(svg), ptr0, len0, isLikeNone(custom_font_buffers) ? 0 : addHeapObject(custom_font_buffers));
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          this.__wbg_ptr = r0 >>> 0;
          return this;
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Get the SVG width
      * @returns {number}
      */
      get width() {
        const ret = wasm.resvg_width(this.__wbg_ptr);
        return ret;
      }
      /**
      * Get the SVG height
      * @returns {number}
      */
      get height() {
        const ret = wasm.resvg_height(this.__wbg_ptr);
        return ret;
      }
      /**
      * Renders an SVG in Wasm
      * @returns {RenderedImage}
      */
      render() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_render(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return RenderedImage.__wrap(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * Output usvg-simplified SVG string
      * @returns {string}
      */
      toString() {
        let deferred1_0;
        let deferred1_1;
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_toString(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          deferred1_0 = r0;
          deferred1_1 = r1;
          return getStringFromWasm0(r0, r1);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
          wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
      }
      /**
      * Calculate a maximum bounding box of all visible elements in this SVG.
      *
      * Note: path bounding box are approx values.
      * @returns {BBox | undefined}
      */
      innerBBox() {
        const ret = wasm.resvg_innerBBox(this.__wbg_ptr);
        return ret === 0 ? void 0 : BBox.__wrap(ret);
      }
      /**
      * Calculate a maximum bounding box of all visible elements in this SVG.
      * This will first apply transform.
      * Similar to `SVGGraphicsElement.getBBox()` DOM API.
      * @returns {BBox | undefined}
      */
      getBBox() {
        const ret = wasm.resvg_getBBox(this.__wbg_ptr);
        return ret === 0 ? void 0 : BBox.__wrap(ret);
      }
      /**
      * Use a given `BBox` to crop the svg. Currently this method simply changes
      * the viewbox/size of the svg and do not move the elements for simplicity
      * @param {BBox} bbox
      */
      cropByBBox(bbox) {
        _assertClass(bbox, BBox);
        wasm.resvg_cropByBBox(this.__wbg_ptr, bbox.__wbg_ptr);
      }
      /**
      * @returns {Array<any>}
      */
      imagesToResolve() {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          wasm.resvg_imagesToResolve(retptr, this.__wbg_ptr);
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          var r2 = getInt32Memory0()[retptr / 4 + 2];
          if (r2) {
            throw takeObject(r1);
          }
          return takeObject(r0);
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
      /**
      * @param {string} href
      * @param {Uint8Array} buffer
      */
      resolveImage(href, buffer) {
        try {
          const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
          const ptr0 = passStringToWasm0(href, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
          const len0 = WASM_VECTOR_LEN;
          wasm.resvg_resolveImage(retptr, this.__wbg_ptr, ptr0, len0, addHeapObject(buffer));
          var r0 = getInt32Memory0()[retptr / 4 + 0];
          var r1 = getInt32Memory0()[retptr / 4 + 1];
          if (r1) {
            throw takeObject(r0);
          }
        } finally {
          wasm.__wbindgen_add_to_stack_pointer(16);
        }
      }
    };
    async function __wbg_load(module22, imports) {
      if (typeof Response === "function" && module22 instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === "function") {
          try {
            return await WebAssembly.instantiateStreaming(module22, imports);
          } catch (e) {
            if (module22.headers.get("Content-Type") != "application/wasm") {
              console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
            } else {
              throw e;
            }
          }
        }
        const bytes = await module22.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
      } else {
        const instance = await WebAssembly.instantiate(module22, imports);
        if (instance instanceof WebAssembly.Instance) {
          return { instance, module: module22 };
        } else {
          return instance;
        }
      }
    }
    function __wbg_get_imports() {
      const imports = {};
      imports.wbg = {};
      imports.wbg.__wbg_new_28c511d9baebfa89 = function(arg0, arg1) {
        const ret = new Error(getStringFromWasm0(arg0, arg1));
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_memory = function() {
        const ret = wasm.memory;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_buffer_12d079cc21e14bdb = function(arg0) {
        const ret = getObject(arg0).buffer;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_newwithbyteoffsetandlength_aa4a17c33a06e5cb = function(arg0, arg1, arg2) {
        const ret = new Uint8Array(getObject(arg0), arg1 >>> 0, arg2 >>> 0);
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
        takeObject(arg0);
      };
      imports.wbg.__wbg_new_63b92bc8671ed464 = function(arg0) {
        const ret = new Uint8Array(getObject(arg0));
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_values_839f3396d5aac002 = function(arg0) {
        const ret = getObject(arg0).values();
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_next_196c84450b364254 = function() {
        return handleError(function(arg0) {
          const ret = getObject(arg0).next();
          return addHeapObject(ret);
        }, arguments);
      };
      imports.wbg.__wbg_done_298b57d23c0fc80c = function(arg0) {
        const ret = getObject(arg0).done;
        return ret;
      };
      imports.wbg.__wbg_value_d93c65011f51a456 = function(arg0) {
        const ret = getObject(arg0).value;
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_instanceof_Uint8Array_2b3bbecd033d19f6 = function(arg0) {
        let result;
        try {
          result = getObject(arg0) instanceof Uint8Array;
        } catch (_) {
          result = false;
        }
        const ret = result;
        return ret;
      };
      imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
        const obj = getObject(arg1);
        const ret = typeof obj === "string" ? obj : void 0;
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getInt32Memory0()[arg0 / 4 + 1] = len1;
        getInt32Memory0()[arg0 / 4 + 0] = ptr1;
      };
      imports.wbg.__wbg_new_16b304a2cfa7ff4a = function() {
        const ret = new Array();
        return addHeapObject(ret);
      };
      imports.wbg.__wbindgen_string_new = function(arg0, arg1) {
        const ret = getStringFromWasm0(arg0, arg1);
        return addHeapObject(ret);
      };
      imports.wbg.__wbg_push_a5b05aedc7234f9f = function(arg0, arg1) {
        const ret = getObject(arg0).push(getObject(arg1));
        return ret;
      };
      imports.wbg.__wbg_length_c20a40f15020d68a = function(arg0) {
        const ret = getObject(arg0).length;
        return ret;
      };
      imports.wbg.__wbg_set_a47bac70306a19a7 = function(arg0, arg1, arg2) {
        getObject(arg0).set(getObject(arg1), arg2 >>> 0);
      };
      imports.wbg.__wbindgen_throw = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
      };
      return imports;
    }
    function __wbg_init_memory(imports, maybe_memory) {
    }
    function __wbg_finalize_init(instance, module22) {
      wasm = instance.exports;
      __wbg_init.__wbindgen_wasm_module = module22;
      cachedInt32Memory0 = null;
      cachedUint8Memory0 = null;
      return wasm;
    }
    async function __wbg_init(input) {
      if (wasm !== void 0)
        return wasm;
      if (typeof input === "undefined") {
        input = new URL("index_bg.wasm", void 0);
      }
      const imports = __wbg_get_imports();
      if (typeof input === "string" || typeof Request === "function" && input instanceof Request || typeof URL === "function" && input instanceof URL) {
        input = fetch(input);
      }
      __wbg_init_memory(imports);
      const { instance, module: module22 } = await __wbg_load(await input, imports);
      return __wbg_finalize_init(instance, module22);
    }
    var dist_default = __wbg_init;
    var initialized2 = false;
    var initWasm = async (module_or_path) => {
      if (initialized2) {
        throw new Error("Already initialized. The `initWasm()` function can be used only once.");
      }
      await dist_default(await module_or_path);
      initialized2 = true;
    };
    var Resvg2 = class extends Resvg {
      /**
       * @param {Uint8Array | string} svg
       * @param {ResvgRenderOptions | undefined} options
       */
      constructor(svg, options) {
        if (!initialized2)
          throw new Error("Wasm has not been initialized. Call `initWasm()` function.");
        const font = options == null ? void 0 : options.font;
        if (!!font && isCustomFontsOptions(font)) {
          const serializableOptions = {
            ...options,
            font: {
              ...font,
              fontBuffers: void 0
            }
          };
          super(svg, JSON.stringify(serializableOptions), font.fontBuffers);
        } else {
          super(svg, JSON.stringify(options));
        }
      }
    };
    function isCustomFontsOptions(value) {
      return Object.prototype.hasOwnProperty.call(value, "fontBuffers");
    }
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/icns-encoder.js
var require_icns_encoder = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/icns-encoder.js"(exports2, module2) {
    module2.exports = {
      encode(buffer) {
        const bufs = [];
        let i = 0;
        while (i < buffer.length) {
          const byte = buffer[i];
          if (i + 2 >= buffer.length) {
            const buf = Buffer.alloc(1);
            buf[0] = buffer.length - i;
            bufs.push(buf);
            bufs.push(buffer.slice(i, buffer.length));
            break;
          }
          const repeat = byte === buffer[i + 1] && byte === buffer[i + 2];
          if (repeat) {
            let j = i + 2;
            let length = 3;
            while (++j < buffer.length && byte === buffer[j] && length < 130) {
              length++;
            }
            const buf = Buffer.alloc(2);
            buf[0] = length + 128 - 3;
            buf[1] = byte;
            bufs.push(buf);
            i = j;
          } else {
            let j = i + 2;
            let length = 3;
            let prev = buffer[j];
            let repeatLength = 1;
            while (++j < buffer.length && length < 128) {
              if (prev === buffer[j]) {
                if (++repeatLength > 2) {
                  break;
                }
              } else {
                prev = buffer[j];
                repeatLength = 1;
              }
              length++;
            }
            if (repeatLength > 2) {
              j -= 2;
              length -= 2;
            }
            const buf = Buffer.alloc(1);
            buf[0] = length - 1;
            bufs.push(buf);
            bufs.push(buffer.slice(i, j));
            i = j;
          }
        }
        const list = bufs;
        const totalLength = bufs.reduce((carry, buf) => carry + buf.length, 0);
        return Buffer.concat(list, totalLength);
      },
      decode(buffer) {
        const bufs = [];
        let i = 0;
        while (i < buffer.length) {
          let length = buffer[i];
          let buf;
          if (length >= 128) {
            length = length - 128 + 3;
            buf = Buffer.alloc(length, buffer.slice(i + 1, i + 2));
            i += 2;
          } else {
            buf = buffer.slice(i + 1, i + length + 2);
            i += length + 2;
          }
          bufs.push(buf);
        }
        const list = bufs;
        const totalLength = bufs.reduce((carry, buf) => carry + buf.length, 0);
        return Buffer.concat(list, totalLength);
      }
    };
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/resize3.js
var require_resize3 = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/resize3.js"(exports2, module2) {
    module2.exports = {
      nearestNeighbor(src, dst) {
        const wSrc = src.width;
        const hSrc = src.height;
        const wDst = dst.width;
        const hDst = dst.height;
        const bufSrc = src.data;
        const bufDst = dst.data;
        for (let i = 0; i < hDst; i++) {
          for (let j = 0; j < wDst; j++) {
            let posDst = (i * wDst + j) * 4;
            const iSrc = Math.floor(i * hSrc / hDst);
            const jSrc = Math.floor(j * wSrc / wDst);
            let posSrc = (iSrc * wSrc + jSrc) * 4;
            bufDst[posDst++] = bufSrc[posSrc++];
            bufDst[posDst++] = bufSrc[posSrc++];
            bufDst[posDst++] = bufSrc[posSrc++];
            bufDst[posDst++] = bufSrc[posSrc++];
          }
        }
      },
      bilinearInterpolation(src, dst) {
        const wSrc = src.width;
        const hSrc = src.height;
        const wDst = dst.width;
        const hDst = dst.height;
        const bufSrc = src.data;
        const bufDst = dst.data;
        const assign = function(pos, offset, x, xMin, xMax, y, yMin, yMax) {
          let posMin = (yMin * wSrc + xMin) * 4 + offset;
          let posMax = (yMin * wSrc + xMax) * 4 + offset;
          const vMin = xMin === xMax ? bufSrc[posMin] : Math.round((x - xMin) * bufSrc[posMax] + (xMax - x) * bufSrc[posMin]);
          if (yMax === yMin) {
            bufDst[pos + offset] = vMin;
          } else {
            posMin = (yMax * wSrc + xMin) * 4 + offset;
            posMax = (yMax * wSrc + xMax) * 4 + offset;
            const vMax = xMin === xMax ? bufSrc[posMin] : Math.round((x - xMin) * bufSrc[posMax] + (xMax - x) * bufSrc[posMin]);
            bufDst[pos + offset] = yMin === yMax ? vMin : Math.round((y - yMin) * vMax + (yMax - y) * vMin);
          }
        };
        for (let i = 0; i < hDst; i++) {
          for (let j = 0; j < wDst; j++) {
            const posDst = (i * wDst + j) * 4;
            const x = j * wSrc / wDst;
            const xMin = Math.floor(x);
            const xMax = Math.min(Math.ceil(x), wSrc - 1);
            const y = i * hSrc / hDst;
            const yMin = Math.floor(y);
            const yMax = Math.min(Math.ceil(y), hSrc - 1);
            assign(posDst, 0, x, xMin, xMax, y, yMin, yMax);
            assign(posDst, 1, x, xMin, xMax, y, yMin, yMax);
            assign(posDst, 2, x, xMin, xMax, y, yMin, yMax);
            assign(posDst, 3, x, xMin, xMax, y, yMin, yMax);
          }
        }
      },
      bicubicInterpolation(src, dst) {
        const bufSrc = src.data;
        const bufDst = dst.data;
        const wSrc = src.width;
        const hSrc = src.height;
        const wDst = dst.width;
        const hDst = dst.height;
        const wM = Math.max(1, Math.floor(wSrc / wDst));
        const wDst2 = wDst * wM;
        const hM = Math.max(1, Math.floor(hSrc / hDst));
        const hDst2 = hDst * hM;
        const buf1 = Buffer.alloc(wDst2 * hSrc * 4);
        for (let i = 0; i < hSrc; i++) {
          for (let j = 0; j < wDst2; j++) {
            const x = j * (wSrc - 1) / wDst2;
            const xPos = Math.floor(x);
            const t = x - xPos;
            const srcPos = (i * wSrc + xPos) * 4;
            const buf1Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = srcPos + k;
              const x0 = xPos > 0 ? bufSrc[kPos - 4] : 2 * bufSrc[kPos] - bufSrc[kPos + 4];
              const x1 = bufSrc[kPos];
              const x2 = bufSrc[kPos + 4];
              const x3 = xPos < wSrc - 2 ? bufSrc[kPos + 8] : 2 * bufSrc[kPos + 4] - bufSrc[kPos];
              buf1[buf1Pos + k] = Math.max(0, Math.min(255, (x3 - x2 - x0 + x1) * (t * t * t) + (x0 - x1 - (x3 - x2 - x0 + x1)) * (t * t) + (x2 - x0) * t + x1));
            }
          }
        }
        const buf2 = Buffer.alloc(wDst2 * hDst2 * 4);
        for (let i = 0; i < hDst2; i++) {
          for (let j = 0; j < wDst2; j++) {
            const y = i * (hSrc - 1) / hDst2;
            const yPos = Math.floor(y);
            const t = y - yPos;
            const buf1Pos = (yPos * wDst2 + j) * 4;
            const buf2Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = buf1Pos + k;
              const y0 = yPos > 0 ? buf1[kPos - wDst2 * 4] : 2 * buf1[kPos] - buf1[kPos + wDst2 * 4];
              const y1 = buf1[kPos];
              const y2 = buf1[kPos + wDst2 * 4];
              const y3 = yPos < hSrc - 2 ? buf1[kPos + wDst2 * 8] : 2 * buf1[kPos + wDst2 * 4] - buf1[kPos];
              buf2[buf2Pos + k] = Math.max(0, Math.min(255, (y3 - y2 - y0 + y1) * (t * t * t) + (y0 - y1 - (y3 - y2 - y0 + y1)) * (t * t) + (y2 - y0) * t + y1));
            }
          }
        }
        const m = wM * hM;
        if (m > 1) {
          for (let i = 0; i < hDst; i++) {
            for (let j = 0; j < wDst; j++) {
              let r = 0;
              let g = 0;
              let b = 0;
              let a = 0;
              let realColors = 0;
              for (let y = 0; y < hM; y++) {
                const yPos = i * hM + y;
                for (let x = 0; x < wM; x++) {
                  const xPos = j * wM + x;
                  const xyPos = (yPos * wDst2 + xPos) * 4;
                  const pixelAplha = buf2[xyPos + 3];
                  if (pixelAplha) {
                    r += buf2[xyPos];
                    g += buf2[xyPos + 1];
                    b += buf2[xyPos + 2];
                    realColors++;
                  }
                  a += pixelAplha;
                }
              }
              const pos = (i * wDst + j) * 4;
              bufDst[pos] = realColors ? Math.round(r / realColors) : 0;
              bufDst[pos + 1] = realColors ? Math.round(g / realColors) : 0;
              bufDst[pos + 2] = realColors ? Math.round(b / realColors) : 0;
              bufDst[pos + 3] = Math.round(a / m);
            }
          }
        } else {
          dst.data = buf2;
        }
      },
      hermiteInterpolation(src, dst) {
        const bufSrc = src.data;
        const bufDst = dst.data;
        const wSrc = src.width;
        const hSrc = src.height;
        const wDst = dst.width;
        const hDst = dst.height;
        const wM = Math.max(1, Math.floor(wSrc / wDst));
        const wDst2 = wDst * wM;
        const hM = Math.max(1, Math.floor(hSrc / hDst));
        const hDst2 = hDst * hM;
        const buf1 = Buffer.alloc(wDst2 * hSrc * 4);
        for (let i = 0; i < hSrc; i++) {
          for (let j = 0; j < wDst2; j++) {
            const x = j * (wSrc - 1) / wDst2;
            const xPos = Math.floor(x);
            const t = x - xPos;
            const srcPos = (i * wSrc + xPos) * 4;
            const buf1Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = srcPos + k;
              const x0 = xPos > 0 ? bufSrc[kPos - 4] : 2 * bufSrc[kPos] - bufSrc[kPos + 4];
              const x1 = bufSrc[kPos];
              const x2 = bufSrc[kPos + 4];
              const x3 = xPos < wSrc - 2 ? bufSrc[kPos + 8] : 2 * bufSrc[kPos + 4] - bufSrc[kPos];
              buf1[buf1Pos + k] = Math.max(0, Math.min(255, Math.round((((0.5 * (x3 - x0) + 1.5 * (x1 - x2)) * t + (x0 - 2.5 * x1 + 2 * x2 - 0.5 * x3)) * t + 0.5 * (x2 - x0)) * t + x1)));
            }
          }
        }
        const buf2 = Buffer.alloc(wDst2 * hDst2 * 4);
        for (let i = 0; i < hDst2; i++) {
          for (let j = 0; j < wDst2; j++) {
            const y = i * (hSrc - 1) / hDst2;
            const yPos = Math.floor(y);
            const t = y - yPos;
            const buf1Pos = (yPos * wDst2 + j) * 4;
            const buf2Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = buf1Pos + k;
              const y0 = yPos > 0 ? buf1[kPos - wDst2 * 4] : 2 * buf1[kPos] - buf1[kPos + wDst2 * 4];
              const y1 = buf1[kPos];
              const y2 = buf1[kPos + wDst2 * 4];
              const y3 = yPos < hSrc - 2 ? buf1[kPos + wDst2 * 8] : 2 * buf1[kPos + wDst2 * 4] - buf1[kPos];
              buf2[buf2Pos + k] = Math.max(0, Math.min(255, Math.round((((0.5 * (y3 - y0) + 1.5 * (y1 - y2)) * t + (y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3)) * t + 0.5 * (y2 - y0)) * t + y1)));
            }
          }
        }
        const m = wM * hM;
        if (m > 1) {
          for (let i = 0; i < hDst; i++) {
            for (let j = 0; j < wDst; j++) {
              let r = 0;
              let g = 0;
              let b = 0;
              let a = 0;
              let realColors = 0;
              for (let y = 0; y < hM; y++) {
                const yPos = i * hM + y;
                for (let x = 0; x < wM; x++) {
                  const xPos = j * wM + x;
                  const xyPos = (yPos * wDst2 + xPos) * 4;
                  const pixelAplha = buf2[xyPos + 3];
                  if (pixelAplha) {
                    r += buf2[xyPos];
                    g += buf2[xyPos + 1];
                    b += buf2[xyPos + 2];
                    realColors++;
                  }
                  a += pixelAplha;
                }
              }
              const pos = (i * wDst + j) * 4;
              bufDst[pos] = realColors ? Math.round(r / realColors) : 0;
              bufDst[pos + 1] = realColors ? Math.round(g / realColors) : 0;
              bufDst[pos + 2] = realColors ? Math.round(b / realColors) : 0;
              bufDst[pos + 3] = Math.round(a / m);
            }
          }
        } else {
          dst.data = buf2;
        }
      },
      bezierInterpolation(src, dst) {
        const bufSrc = src.data;
        const bufDst = dst.data;
        const wSrc = src.width;
        const hSrc = src.height;
        const wDst = dst.width;
        const hDst = dst.height;
        const wM = Math.max(1, Math.floor(wSrc / wDst));
        const wDst2 = wDst * wM;
        const hM = Math.max(1, Math.floor(hSrc / hDst));
        const hDst2 = hDst * hM;
        const buf1 = Buffer.alloc(wDst2 * hSrc * 4);
        for (let i = 0; i < hSrc; i++) {
          for (let j = 0; j < wDst2; j++) {
            const x = j * (wSrc - 1) / wDst2;
            const xPos = Math.floor(x);
            const t = x - xPos;
            const srcPos = (i * wSrc + xPos) * 4;
            const buf1Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = srcPos + k;
              const x0 = xPos > 0 ? bufSrc[kPos - 4] : 2 * bufSrc[kPos] - bufSrc[kPos + 4];
              const x1 = bufSrc[kPos];
              const x2 = bufSrc[kPos + 4];
              const x3 = xPos < wSrc - 2 ? bufSrc[kPos + 8] : 2 * bufSrc[kPos + 4] - bufSrc[kPos];
              buf1[buf1Pos + k] = Math.max(0, Math.min(255, Math.round(x1 * (1 - t) * (1 - t) * (1 - t) + 3 * (x1 + (x2 - x0) / 4) * (1 - t) * (1 - t) * t + 3 * (x2 - (x3 - x1) / 4) * (1 - t) * t * t + x2 * t * t * t)));
            }
          }
        }
        const buf2 = Buffer.alloc(wDst2 * hDst2 * 4);
        for (let i = 0; i < hDst2; i++) {
          for (let j = 0; j < wDst2; j++) {
            const y = i * (hSrc - 1) / hDst2;
            const yPos = Math.floor(y);
            const t = y - yPos;
            const buf1Pos = (yPos * wDst2 + j) * 4;
            const buf2Pos = (i * wDst2 + j) * 4;
            for (let k = 0; k < 4; k++) {
              const kPos = buf1Pos + k;
              const y0 = yPos > 0 ? buf1[kPos - wDst2 * 4] : 2 * buf1[kPos] - buf1[kPos + wDst2 * 4];
              const y1 = buf1[kPos];
              const y2 = buf1[kPos + wDst2 * 4];
              const y3 = yPos < hSrc - 2 ? buf1[kPos + wDst2 * 8] : 2 * buf1[kPos + wDst2 * 4] - buf1[kPos];
              buf2[buf2Pos + k] = Math.max(0, Math.min(255, Math.round(y1 * (1 - t) * (1 - t) * (1 - t) + 3 * (y1 + (y2 - y0) / 4) * (1 - t) * (1 - t) * t + 3 * (y2 - (y3 - y1) / 4) * (1 - t) * t * t + y2 * t * t * t)));
            }
          }
        }
        const m = wM * hM;
        if (m > 1) {
          for (let i = 0; i < hDst; i++) {
            for (let j = 0; j < wDst; j++) {
              let r = 0;
              let g = 0;
              let b = 0;
              let a = 0;
              let realColors = 0;
              for (let y = 0; y < hM; y++) {
                const yPos = i * hM + y;
                for (let x = 0; x < wM; x++) {
                  const xPos = j * wM + x;
                  const xyPos = (yPos * wDst2 + xPos) * 4;
                  const pixelAplha = buf2[xyPos + 3];
                  if (pixelAplha) {
                    r += buf2[xyPos];
                    g += buf2[xyPos + 1];
                    b += buf2[xyPos + 2];
                    realColors++;
                  }
                  a += pixelAplha;
                }
              }
              const pos = (i * wDst + j) * 4;
              bufDst[pos] = realColors ? Math.round(r / realColors) : 0;
              bufDst[pos + 1] = realColors ? Math.round(g / realColors) : 0;
              bufDst[pos + 2] = realColors ? Math.round(b / realColors) : 0;
              bufDst[pos + 3] = Math.round(a / m);
            }
          }
        } else {
          dst.data = buf2;
        }
      }
    };
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/resize4.js
var require_resize4 = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/resize4.js"(exports2, module2) {
    module2.exports = {
      BicubicInterpolation(x, y, values) {
        function TERP(t, a, b, c, d) {
          return 0.5 * (c - a + (2 * a - 5 * b + 4 * c - d + (3 * (b - c) + d - a) * t) * t) * t + b;
        }
        var i0, i1, i2, i3;
        i0 = TERP(x, values[0][0], values[1][0], values[2][0], values[3][0]);
        i1 = TERP(x, values[0][1], values[1][1], values[2][1], values[3][1]);
        i2 = TERP(x, values[0][2], values[1][2], values[2][2], values[3][2]);
        i3 = TERP(x, values[0][3], values[1][3], values[2][3], values[3][3]);
        return TERP(y, i0, i1, i2, i3);
      },
      ivect(ix, iy, w) {
        return (ix + w * iy) * 4;
      },
      bilinear(srcImg, destImg, scale) {
        function inner(f00, f10, f01, f11, x, y) {
          var un_x = 1 - x;
          var un_y = 1 - y;
          return f00 * un_x * un_y + f10 * x * un_y + f01 * un_x * y + f11 * x * y;
        }
        var i, j;
        var iyv2, iy02, iy1, ixv2, ix02, ix1;
        var idxD2, idxS00, idxS10, idxS01, idxS11;
        var dx, dy;
        var r, g, b, a;
        for (i = 0; i < destImg.height; ++i) {
          iyv2 = i / scale;
          iy02 = Math.floor(iyv2);
          iy1 = Math.ceil(iyv2) > srcImg.height - 1 ? srcImg.height - 1 : Math.ceil(iyv2);
          for (j = 0; j < destImg.width; ++j) {
            ixv2 = j / scale;
            ix02 = Math.floor(ixv2);
            ix1 = Math.ceil(ixv2) > srcImg.width - 1 ? srcImg.width - 1 : Math.ceil(ixv2);
            idxD2 = (j + destImg.width * i) * 4;
            idxS00 = (ix02 + srcImg.width * iy02) * 4;
            idxS10 = (ix1 + srcImg.width * iy02) * 4;
            idxS01 = (ix02 + srcImg.width * iy1) * 4;
            idxS11 = (ix1 + srcImg.width * iy1) * 4;
            dx = ixv2 - ix02;
            dy = iyv2 - iy02;
            r = inner(
              srcImg.data[idxS00],
              srcImg.data[idxS10],
              srcImg.data[idxS01],
              srcImg.data[idxS11],
              dx,
              dy
            );
            destImg.data[idxD2] = r;
            g = inner(
              srcImg.data[idxS00 + 1],
              srcImg.data[idxS10 + 1],
              srcImg.data[idxS01 + 1],
              srcImg.data[idxS11 + 1],
              dx,
              dy
            );
            destImg.data[idxD2 + 1] = g;
            b = inner(
              srcImg.data[idxS00 + 2],
              srcImg.data[idxS10 + 2],
              srcImg.data[idxS01 + 2],
              srcImg.data[idxS11 + 2],
              dx,
              dy
            );
            destImg.data[idxD2 + 2] = b;
            a = inner(
              srcImg.data[idxS00 + 3],
              srcImg.data[idxS10 + 3],
              srcImg.data[idxS01 + 3],
              srcImg.data[idxS11 + 3],
              dx,
              dy
            );
            destImg.data[idxD2 + 3] = a;
          }
        }
      },
      bicubic(srcImg, destImg, scale) {
        var i, j;
        var dx, dy;
        var repeatX, repeatY;
        var offset_row0, offset_row1, offset_row2, offset_row3;
        var offset_col0, offset_col1, offset_col2, offset_col3;
        var red_pixels, green_pixels, blue_pixels, alpha_pixels;
        for (i = 0; i < destImg.height; ++i) {
          iyv = i / scale;
          iy0 = Math.floor(iyv);
          repeatY = 0;
          if (iy0 < 1) repeatY = -1;
          else if (iy0 > srcImg.height - 3) repeatY = iy0 - (srcImg.height - 3);
          for (j = 0; j < destImg.width; ++j) {
            ixv = j / scale;
            ix0 = Math.floor(ixv);
            repeatX = 0;
            if (ix0 < 1) repeatX = -1;
            else if (ix0 > srcImg.width - 3) repeatX = ix0 - (srcImg.width - 3);
            offset_row1 = (iy0 * srcImg.width + ix0) * 4;
            offset_row0 = repeatY < 0 ? offset_row1 : ((iy0 - 1) * srcImg.width + ix0) * 4;
            offset_row2 = repeatY > 1 ? offset_row1 : ((iy0 + 1) * srcImg.width + ix0) * 4;
            offset_row3 = repeatY > 0 ? offset_row2 : ((iy0 + 2) * srcImg.width + ix0) * 4;
            offset_col1 = 0;
            offset_col0 = repeatX < 0 ? offset_col1 : -4;
            offset_col2 = repeatX > 1 ? offset_col1 : 4;
            offset_col3 = repeatX > 0 ? offset_col2 : 8;
            red_pixels = [
              [srcImg.data[offset_row0 + offset_col0], srcImg.data[offset_row1 + offset_col0], srcImg.data[offset_row2 + offset_col0], srcImg.data[offset_row3 + offset_col0]],
              [srcImg.data[offset_row0 + offset_col1], srcImg.data[offset_row1 + offset_col1], srcImg.data[offset_row2 + offset_col1], srcImg.data[offset_row3 + offset_col1]],
              [srcImg.data[offset_row0 + offset_col2], srcImg.data[offset_row1 + offset_col2], srcImg.data[offset_row2 + offset_col2], srcImg.data[offset_row3 + offset_col2]],
              [srcImg.data[offset_row0 + offset_col3], srcImg.data[offset_row1 + offset_col3], srcImg.data[offset_row2 + offset_col3], srcImg.data[offset_row3 + offset_col3]]
            ];
            offset_row0++;
            offset_row1++;
            offset_row2++;
            offset_row3++;
            green_pixels = [
              [srcImg.data[offset_row0 + offset_col0], srcImg.data[offset_row1 + offset_col0], srcImg.data[offset_row2 + offset_col0], srcImg.data[offset_row3 + offset_col0]],
              [srcImg.data[offset_row0 + offset_col1], srcImg.data[offset_row1 + offset_col1], srcImg.data[offset_row2 + offset_col1], srcImg.data[offset_row3 + offset_col1]],
              [srcImg.data[offset_row0 + offset_col2], srcImg.data[offset_row1 + offset_col2], srcImg.data[offset_row2 + offset_col2], srcImg.data[offset_row3 + offset_col2]],
              [srcImg.data[offset_row0 + offset_col3], srcImg.data[offset_row1 + offset_col3], srcImg.data[offset_row2 + offset_col3], srcImg.data[offset_row3 + offset_col3]]
            ];
            offset_row0++;
            offset_row1++;
            offset_row2++;
            offset_row3++;
            blue_pixels = [
              [srcImg.data[offset_row0 + offset_col0], srcImg.data[offset_row1 + offset_col0], srcImg.data[offset_row2 + offset_col0], srcImg.data[offset_row3 + offset_col0]],
              [srcImg.data[offset_row0 + offset_col1], srcImg.data[offset_row1 + offset_col1], srcImg.data[offset_row2 + offset_col1], srcImg.data[offset_row3 + offset_col1]],
              [srcImg.data[offset_row0 + offset_col2], srcImg.data[offset_row1 + offset_col2], srcImg.data[offset_row2 + offset_col2], srcImg.data[offset_row3 + offset_col2]],
              [srcImg.data[offset_row0 + offset_col3], srcImg.data[offset_row1 + offset_col3], srcImg.data[offset_row2 + offset_col3], srcImg.data[offset_row3 + offset_col3]]
            ];
            offset_row0++;
            offset_row1++;
            offset_row2++;
            offset_row3++;
            alpha_pixels = [
              [srcImg.data[offset_row0 + offset_col0], srcImg.data[offset_row1 + offset_col0], srcImg.data[offset_row2 + offset_col0], srcImg.data[offset_row3 + offset_col0]],
              [srcImg.data[offset_row0 + offset_col1], srcImg.data[offset_row1 + offset_col1], srcImg.data[offset_row2 + offset_col1], srcImg.data[offset_row3 + offset_col1]],
              [srcImg.data[offset_row0 + offset_col2], srcImg.data[offset_row1 + offset_col2], srcImg.data[offset_row2 + offset_col2], srcImg.data[offset_row3 + offset_col2]],
              [srcImg.data[offset_row0 + offset_col3], srcImg.data[offset_row1 + offset_col3], srcImg.data[offset_row2 + offset_col3], srcImg.data[offset_row3 + offset_col3]]
            ];
            dx = ixv - ix0;
            dy = iyv - iy0;
            idxD = (j + destImg.width * i) * 4;
            destImg.data[idxD] = this.BicubicInterpolation(dx, dy, red_pixels);
            destImg.data[idxD + 1] = this.BicubicInterpolation(dx, dy, green_pixels);
            destImg.data[idxD + 2] = this.BicubicInterpolation(dx, dy, blue_pixels);
            destImg.data[idxD + 3] = this.BicubicInterpolation(dx, dy, alpha_pixels);
          }
        }
      }
    };
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/UZIP.js
var require_UZIP = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/UZIP.js"(exports2, module2) {
    var UZIP2 = {};
    UZIP2["parse"] = function(buf, onlyNames) {
      var rUs = UZIP2.bin.readUshort, rUi = UZIP2.bin.readUint, o = 0, out = {};
      var data = new Uint8Array(buf);
      var eocd = data.length - 4;
      while (rUi(data, eocd) != 101010256) eocd--;
      var o = eocd;
      o += 4;
      o += 4;
      var cnu = rUs(data, o);
      o += 2;
      var cnt = rUs(data, o);
      o += 2;
      var csize = rUi(data, o);
      o += 4;
      var coffs = rUi(data, o);
      o += 4;
      o = coffs;
      for (var i = 0; i < cnu; i++) {
        var sign = rUi(data, o);
        o += 4;
        o += 4;
        o += 4;
        o += 4;
        var crc32 = rUi(data, o);
        o += 4;
        var csize = rUi(data, o);
        o += 4;
        var usize = rUi(data, o);
        o += 4;
        var nl = rUs(data, o), el = rUs(data, o + 2), cl = rUs(data, o + 4);
        o += 6;
        o += 8;
        var roff = rUi(data, o);
        o += 4;
        o += nl + el + cl;
        UZIP2._readLocal(data, roff, out, csize, usize, onlyNames);
      }
      return out;
    };
    UZIP2._readLocal = function(data, o, out, csize, usize, onlyNames) {
      var rUs = UZIP2.bin.readUshort, rUi = UZIP2.bin.readUint;
      var sign = rUi(data, o);
      o += 4;
      var ver = rUs(data, o);
      o += 2;
      var gpflg = rUs(data, o);
      o += 2;
      var cmpr = rUs(data, o);
      o += 2;
      var time = rUi(data, o);
      o += 4;
      var crc32 = rUi(data, o);
      o += 4;
      o += 8;
      var nlen = rUs(data, o);
      o += 2;
      var elen = rUs(data, o);
      o += 2;
      var name = UZIP2.bin.readUTF8(data, o, nlen);
      o += nlen;
      o += elen;
      if (onlyNames) {
        out[name] = { size: usize, csize };
        return;
      }
      var file = new Uint8Array(data.buffer, o);
      if (false) {
      } else if (cmpr == 0) out[name] = new Uint8Array(file.buffer.slice(o, o + csize));
      else if (cmpr == 8) {
        var buf = new Uint8Array(usize);
        UZIP2.inflateRaw(file, buf);
        out[name] = buf;
      } else throw "unknown compression method: " + cmpr;
    };
    UZIP2.inflateRaw = function(file, buf) {
      return UZIP2.F.inflate(file, buf);
    };
    UZIP2.inflate = function(file, buf) {
      var CMF = file[0], FLG = file[1];
      var CM = CMF & 15, CINFO = CMF >>> 4;
      return UZIP2.inflateRaw(new Uint8Array(file.buffer, file.byteOffset + 2, file.length - 6), buf);
    };
    UZIP2.deflate = function(data, opts) {
      if (opts == null) opts = { level: 6 };
      var off = 0, buf = new Uint8Array(50 + Math.floor(data.length * 1.1));
      buf[off] = 120;
      buf[off + 1] = 156;
      off += 2;
      off = UZIP2.F.deflateRaw(data, buf, off, opts.level);
      var crc = UZIP2.adler(data, 0, data.length);
      buf[off + 0] = crc >>> 24 & 255;
      buf[off + 1] = crc >>> 16 & 255;
      buf[off + 2] = crc >>> 8 & 255;
      buf[off + 3] = crc >>> 0 & 255;
      return new Uint8Array(buf.buffer, 0, off + 4);
    };
    UZIP2.deflateRaw = function(data, opts) {
      if (opts == null) opts = { level: 6 };
      var buf = new Uint8Array(50 + Math.floor(data.length * 1.1));
      var off = UZIP2.F.deflateRaw(data, buf, off, opts.level);
      return new Uint8Array(buf.buffer, 0, off);
    };
    UZIP2.encode = function(obj) {
      var tot = 0, wUi = UZIP2.bin.writeUint, wUs = UZIP2.bin.writeUshort;
      var zpd = {};
      for (var p in obj) {
        var cpr = !UZIP2._noNeed(p), buf = obj[p], crc = UZIP2.crc.crc(buf, 0, buf.length);
        zpd[p] = { cpr, usize: buf.length, crc, file: cpr ? UZIP2.deflateRaw(buf) : buf };
      }
      for (var p in zpd) tot += zpd[p].file.length + 30 + 46 + 2 * UZIP2.bin.sizeUTF8(p);
      tot += 22;
      var data = new Uint8Array(tot), o = 0;
      var fof = [];
      for (var p in zpd) {
        var file = zpd[p];
        fof.push(o);
        o = UZIP2._writeHeader(data, o, p, file, 0);
      }
      var i = 0, ioff = o;
      for (var p in zpd) {
        var file = zpd[p];
        fof.push(o);
        o = UZIP2._writeHeader(data, o, p, file, 1, fof[i++]);
      }
      var csize = o - ioff;
      wUi(data, o, 101010256);
      o += 4;
      o += 4;
      wUs(data, o, i);
      o += 2;
      wUs(data, o, i);
      o += 2;
      wUi(data, o, csize);
      o += 4;
      wUi(data, o, ioff);
      o += 4;
      o += 2;
      return data.buffer;
    };
    UZIP2._noNeed = function(fn) {
      var ext = fn.split(".").pop().toLowerCase();
      return "png,jpg,jpeg,zip".indexOf(ext) != -1;
    };
    UZIP2._writeHeader = function(data, o, p, obj, t, roff) {
      var wUi = UZIP2.bin.writeUint, wUs = UZIP2.bin.writeUshort;
      var file = obj.file;
      wUi(data, o, t == 0 ? 67324752 : 33639248);
      o += 4;
      if (t == 1) o += 2;
      wUs(data, o, 20);
      o += 2;
      wUs(data, o, 0);
      o += 2;
      wUs(data, o, obj.cpr ? 8 : 0);
      o += 2;
      wUi(data, o, 0);
      o += 4;
      wUi(data, o, obj.crc);
      o += 4;
      wUi(data, o, file.length);
      o += 4;
      wUi(data, o, obj.usize);
      o += 4;
      wUs(data, o, UZIP2.bin.sizeUTF8(p));
      o += 2;
      wUs(data, o, 0);
      o += 2;
      if (t == 1) {
        o += 2;
        o += 2;
        o += 6;
        wUi(data, o, roff);
        o += 4;
      }
      var nlen = UZIP2.bin.writeUTF8(data, o, p);
      o += nlen;
      if (t == 0) {
        data.set(file, o);
        o += file.length;
      }
      return o;
    };
    UZIP2.crc = {
      table: function() {
        var tab = new Uint32Array(256);
        for (var n = 0; n < 256; n++) {
          var c = n;
          for (var k = 0; k < 8; k++) {
            if (c & 1) c = 3988292384 ^ c >>> 1;
            else c = c >>> 1;
          }
          tab[n] = c;
        }
        return tab;
      }(),
      update: function(c, buf, off, len) {
        for (var i = 0; i < len; i++) c = UZIP2.crc.table[(c ^ buf[off + i]) & 255] ^ c >>> 8;
        return c;
      },
      crc: function(b, o, l) {
        return UZIP2.crc.update(4294967295, b, o, l) ^ 4294967295;
      }
    };
    UZIP2.adler = function(data, o, len) {
      var a = 1, b = 0;
      var off = o, end = o + len;
      while (off < end) {
        var eend = Math.min(off + 5552, end);
        while (off < eend) {
          a += data[off++];
          b += a;
        }
        a = a % 65521;
        b = b % 65521;
      }
      return b << 16 | a;
    };
    UZIP2.bin = {
      readUshort: function(buff, p) {
        return buff[p] | buff[p + 1] << 8;
      },
      writeUshort: function(buff, p, n) {
        buff[p] = n & 255;
        buff[p + 1] = n >> 8 & 255;
      },
      readUint: function(buff, p) {
        return buff[p + 3] * (256 * 256 * 256) + (buff[p + 2] << 16 | buff[p + 1] << 8 | buff[p]);
      },
      writeUint: function(buff, p, n) {
        buff[p] = n & 255;
        buff[p + 1] = n >> 8 & 255;
        buff[p + 2] = n >> 16 & 255;
        buff[p + 3] = n >> 24 & 255;
      },
      readASCII: function(buff, p, l) {
        var s = "";
        for (var i = 0; i < l; i++) s += String.fromCharCode(buff[p + i]);
        return s;
      },
      writeASCII: function(data, p, s) {
        for (var i = 0; i < s.length; i++) data[p + i] = s.charCodeAt(i);
      },
      pad: function(n) {
        return n.length < 2 ? "0" + n : n;
      },
      readUTF8: function(buff, p, l) {
        var s = "", ns;
        for (var i = 0; i < l; i++) s += "%" + UZIP2.bin.pad(buff[p + i].toString(16));
        try {
          ns = decodeURIComponent(s);
        } catch (e) {
          return UZIP2.bin.readASCII(buff, p, l);
        }
        return ns;
      },
      writeUTF8: function(buff, p, str) {
        var strl = str.length, i = 0;
        for (var ci = 0; ci < strl; ci++) {
          var code = str.charCodeAt(ci);
          if ((code & 4294967295 - (1 << 7) + 1) == 0) {
            buff[p + i] = code;
            i++;
          } else if ((code & 4294967295 - (1 << 11) + 1) == 0) {
            buff[p + i] = 192 | code >> 6;
            buff[p + i + 1] = 128 | code >> 0 & 63;
            i += 2;
          } else if ((code & 4294967295 - (1 << 16) + 1) == 0) {
            buff[p + i] = 224 | code >> 12;
            buff[p + i + 1] = 128 | code >> 6 & 63;
            buff[p + i + 2] = 128 | code >> 0 & 63;
            i += 3;
          } else if ((code & 4294967295 - (1 << 21) + 1) == 0) {
            buff[p + i] = 240 | code >> 18;
            buff[p + i + 1] = 128 | code >> 12 & 63;
            buff[p + i + 2] = 128 | code >> 6 & 63;
            buff[p + i + 3] = 128 | code >> 0 & 63;
            i += 4;
          } else throw "e";
        }
        return i;
      },
      sizeUTF8: function(str) {
        var strl = str.length, i = 0;
        for (var ci = 0; ci < strl; ci++) {
          var code = str.charCodeAt(ci);
          if ((code & 4294967295 - (1 << 7) + 1) == 0) {
            i++;
          } else if ((code & 4294967295 - (1 << 11) + 1) == 0) {
            i += 2;
          } else if ((code & 4294967295 - (1 << 16) + 1) == 0) {
            i += 3;
          } else if ((code & 4294967295 - (1 << 21) + 1) == 0) {
            i += 4;
          } else throw "e";
        }
        return i;
      }
    };
    UZIP2.F = {};
    UZIP2.F.deflateRaw = function(data, out, opos, lvl) {
      var opts = [
        /*
        	 ush good_length; /* reduce lazy search above this match length 
        	 ush max_lazy;    /* do not perform lazy search above this match length 
                ush nice_length; /* quit search above this match length 
        */
        /*      good lazy nice chain */
        /* 0 */
        [0, 0, 0, 0, 0],
        /* store only */
        /* 1 */
        [4, 4, 8, 4, 0],
        /* max speed, no lazy matches */
        /* 2 */
        [4, 5, 16, 8, 0],
        /* 3 */
        [4, 6, 16, 16, 0],
        /* 4 */
        [4, 10, 16, 32, 0],
        /* lazy matches */
        /* 5 */
        [8, 16, 32, 32, 0],
        /* 6 */
        [8, 16, 128, 128, 0],
        /* 7 */
        [8, 32, 128, 256, 0],
        /* 8 */
        [32, 128, 258, 1024, 1],
        /* 9 */
        [32, 258, 258, 4096, 1]
      ];
      var opt = opts[lvl];
      var U = UZIP2.F.U, goodIndex = UZIP2.F._goodIndex, hash = UZIP2.F._hash, putsE = UZIP2.F._putsE;
      var i = 0, pos = opos << 3, cvrd = 0, dlen = data.length;
      if (lvl == 0) {
        while (i < dlen) {
          var len = Math.min(65535, dlen - i);
          putsE(out, pos, i + len == dlen ? 1 : 0);
          pos = UZIP2.F._copyExact(data, i, len, out, pos + 8);
          i += len;
        }
        return pos >>> 3;
      }
      var lits = U.lits, strt = U.strt, prev = U.prev, li = 0, lc = 0, bs = 0, ebits = 0, c = 0, nc = 0;
      if (dlen > 2) {
        nc = UZIP2.F._hash(data, 0);
        strt[nc] = 0;
      }
      var nmch = 0, nmci = 0;
      for (i = 0; i < dlen; i++) {
        c = nc;
        if (i + 1 < dlen - 2) {
          nc = UZIP2.F._hash(data, i + 1);
          var ii = i + 1 & 32767;
          prev[ii] = strt[nc];
          strt[nc] = ii;
        }
        if (cvrd <= i) {
          if ((li > 14e3 || lc > 26697) && dlen - i > 100) {
            if (cvrd < i) {
              lits[li] = i - cvrd;
              li += 2;
              cvrd = i;
            }
            pos = UZIP2.F._writeBlock(i == dlen - 1 || cvrd == dlen ? 1 : 0, lits, li, ebits, data, bs, i - bs, out, pos);
            li = lc = ebits = 0;
            bs = i;
          }
          var mch = 0;
          if (i < dlen - 2) mch = UZIP2.F._bestMatch(data, i, prev, c, Math.min(opt[2], dlen - i), opt[3]);
          var len = mch >>> 16, dst = mch & 65535;
          if (mch != 0) {
            var len = mch >>> 16, dst = mch & 65535;
            var lgi = goodIndex(len, U.of0);
            U.lhst[257 + lgi]++;
            var dgi = goodIndex(dst, U.df0);
            U.dhst[dgi]++;
            ebits += U.exb[lgi] + U.dxb[dgi];
            lits[li] = len << 23 | i - cvrd;
            lits[li + 1] = dst << 16 | lgi << 8 | dgi;
            li += 2;
            cvrd = i + len;
          } else {
            U.lhst[data[i]]++;
          }
          lc++;
        }
      }
      if (bs != i || data.length == 0) {
        if (cvrd < i) {
          lits[li] = i - cvrd;
          li += 2;
          cvrd = i;
        }
        pos = UZIP2.F._writeBlock(1, lits, li, ebits, data, bs, i - bs, out, pos);
        li = 0;
        lc = 0;
        li = lc = ebits = 0;
        bs = i;
      }
      while ((pos & 7) != 0) pos++;
      return pos >>> 3;
    };
    UZIP2.F._bestMatch = function(data, i, prev, c, nice, chain) {
      var ci = i & 32767, pi = prev[ci];
      var dif = ci - pi + (1 << 15) & 32767;
      if (pi == ci || c != UZIP2.F._hash(data, i - dif)) return 0;
      var tl = 0, td = 0;
      var dlim = Math.min(32767, i);
      while (dif <= dlim && --chain != 0 && pi != ci) {
        if (tl == 0 || data[i + tl] == data[i + tl - dif]) {
          var cl = UZIP2.F._howLong(data, i, dif);
          if (cl > tl) {
            tl = cl;
            td = dif;
            if (tl >= nice) break;
            if (dif + 2 < cl) cl = dif + 2;
            var maxd = 0;
            for (var j = 0; j < cl - 2; j++) {
              var ei = i - dif + j + (1 << 15) & 32767;
              var li = prev[ei];
              var curd = ei - li + (1 << 15) & 32767;
              if (curd > maxd) {
                maxd = curd;
                pi = ei;
              }
            }
          }
        }
        ci = pi;
        pi = prev[ci];
        dif += ci - pi + (1 << 15) & 32767;
      }
      return tl << 16 | td;
    };
    UZIP2.F._howLong = function(data, i, dif) {
      if (data[i] != data[i - dif] || data[i + 1] != data[i + 1 - dif] || data[i + 2] != data[i + 2 - dif]) return 0;
      var oi = i, l = Math.min(data.length, i + 258);
      i += 3;
      while (i < l && data[i] == data[i - dif]) i++;
      return i - oi;
    };
    UZIP2.F._hash = function(data, i) {
      return (data[i] << 8 | data[i + 1]) + (data[i + 2] << 4) & 65535;
    };
    UZIP2.saved = 0;
    UZIP2.F._writeBlock = function(BFINAL, lits, li, ebits, data, o0, l0, out, pos) {
      var U = UZIP2.F.U, putsF = UZIP2.F._putsF, putsE = UZIP2.F._putsE;
      var T, ML, MD, MH, numl, numd, numh, lset, dset;
      U.lhst[256]++;
      T = UZIP2.F.getTrees();
      ML = T[0];
      MD = T[1];
      MH = T[2];
      numl = T[3];
      numd = T[4];
      numh = T[5];
      lset = T[6];
      dset = T[7];
      var cstSize = ((pos + 3 & 7) == 0 ? 0 : 8 - (pos + 3 & 7)) + 32 + (l0 << 3);
      var fxdSize = ebits + UZIP2.F.contSize(U.fltree, U.lhst) + UZIP2.F.contSize(U.fdtree, U.dhst);
      var dynSize = ebits + UZIP2.F.contSize(U.ltree, U.lhst) + UZIP2.F.contSize(U.dtree, U.dhst);
      dynSize += 14 + 3 * numh + UZIP2.F.contSize(U.itree, U.ihst) + (U.ihst[16] * 2 + U.ihst[17] * 3 + U.ihst[18] * 7);
      for (var j = 0; j < 286; j++) U.lhst[j] = 0;
      for (var j = 0; j < 30; j++) U.dhst[j] = 0;
      for (var j = 0; j < 19; j++) U.ihst[j] = 0;
      var BTYPE = cstSize < fxdSize && cstSize < dynSize ? 0 : fxdSize < dynSize ? 1 : 2;
      putsF(out, pos, BFINAL);
      putsF(out, pos + 1, BTYPE);
      pos += 3;
      var opos = pos;
      if (BTYPE == 0) {
        while ((pos & 7) != 0) pos++;
        pos = UZIP2.F._copyExact(data, o0, l0, out, pos);
      } else {
        var ltree, dtree;
        if (BTYPE == 1) {
          ltree = U.fltree;
          dtree = U.fdtree;
        }
        if (BTYPE == 2) {
          UZIP2.F.makeCodes(U.ltree, ML);
          UZIP2.F.revCodes(U.ltree, ML);
          UZIP2.F.makeCodes(U.dtree, MD);
          UZIP2.F.revCodes(U.dtree, MD);
          UZIP2.F.makeCodes(U.itree, MH);
          UZIP2.F.revCodes(U.itree, MH);
          ltree = U.ltree;
          dtree = U.dtree;
          putsE(out, pos, numl - 257);
          pos += 5;
          putsE(out, pos, numd - 1);
          pos += 5;
          putsE(out, pos, numh - 4);
          pos += 4;
          for (var i = 0; i < numh; i++) putsE(out, pos + i * 3, U.itree[(U.ordr[i] << 1) + 1]);
          pos += 3 * numh;
          pos = UZIP2.F._codeTiny(lset, U.itree, out, pos);
          pos = UZIP2.F._codeTiny(dset, U.itree, out, pos);
        }
        var off = o0;
        for (var si = 0; si < li; si += 2) {
          var qb = lits[si], len = qb >>> 23, end = off + (qb & (1 << 23) - 1);
          while (off < end) pos = UZIP2.F._writeLit(data[off++], ltree, out, pos);
          if (len != 0) {
            var qc = lits[si + 1], dst = qc >> 16, lgi = qc >> 8 & 255, dgi = qc & 255;
            pos = UZIP2.F._writeLit(257 + lgi, ltree, out, pos);
            putsE(out, pos, len - U.of0[lgi]);
            pos += U.exb[lgi];
            pos = UZIP2.F._writeLit(dgi, dtree, out, pos);
            putsF(out, pos, dst - U.df0[dgi]);
            pos += U.dxb[dgi];
            off += len;
          }
        }
        pos = UZIP2.F._writeLit(256, ltree, out, pos);
      }
      return pos;
    };
    UZIP2.F._copyExact = function(data, off, len, out, pos) {
      var p8 = pos >>> 3;
      out[p8] = len;
      out[p8 + 1] = len >>> 8;
      out[p8 + 2] = 255 - out[p8];
      out[p8 + 3] = 255 - out[p8 + 1];
      p8 += 4;
      out.set(new Uint8Array(data.buffer, off, len), p8);
      return pos + (len + 4 << 3);
    };
    UZIP2.F.getTrees = function() {
      var U = UZIP2.F.U;
      var ML = UZIP2.F._hufTree(U.lhst, U.ltree, 15);
      var MD = UZIP2.F._hufTree(U.dhst, U.dtree, 15);
      var lset = [], numl = UZIP2.F._lenCodes(U.ltree, lset);
      var dset = [], numd = UZIP2.F._lenCodes(U.dtree, dset);
      for (var i = 0; i < lset.length; i += 2) U.ihst[lset[i]]++;
      for (var i = 0; i < dset.length; i += 2) U.ihst[dset[i]]++;
      var MH = UZIP2.F._hufTree(U.ihst, U.itree, 7);
      var numh = 19;
      while (numh > 4 && U.itree[(U.ordr[numh - 1] << 1) + 1] == 0) numh--;
      return [ML, MD, MH, numl, numd, numh, lset, dset];
    };
    UZIP2.F.getSecond = function(a) {
      var b = [];
      for (var i = 0; i < a.length; i += 2) b.push(a[i + 1]);
      return b;
    };
    UZIP2.F.nonZero = function(a) {
      var b = "";
      for (var i = 0; i < a.length; i += 2) if (a[i + 1] != 0) b += (i >> 1) + ",";
      return b;
    };
    UZIP2.F.contSize = function(tree, hst) {
      var s = 0;
      for (var i = 0; i < hst.length; i++) s += hst[i] * tree[(i << 1) + 1];
      return s;
    };
    UZIP2.F._codeTiny = function(set, tree, out, pos) {
      for (var i = 0; i < set.length; i += 2) {
        var l = set[i], rst = set[i + 1];
        pos = UZIP2.F._writeLit(l, tree, out, pos);
        var rsl = l == 16 ? 2 : l == 17 ? 3 : 7;
        if (l > 15) {
          UZIP2.F._putsE(out, pos, rst, rsl);
          pos += rsl;
        }
      }
      return pos;
    };
    UZIP2.F._lenCodes = function(tree, set) {
      var len = tree.length;
      while (len != 2 && tree[len - 1] == 0) len -= 2;
      for (var i = 0; i < len; i += 2) {
        var l = tree[i + 1], nxt = i + 3 < len ? tree[i + 3] : -1, nnxt = i + 5 < len ? tree[i + 5] : -1, prv = i == 0 ? -1 : tree[i - 1];
        if (l == 0 && nxt == l && nnxt == l) {
          var lz = i + 5;
          while (lz + 2 < len && tree[lz + 2] == l) lz += 2;
          var zc = Math.min(lz + 1 - i >>> 1, 138);
          if (zc < 11) set.push(17, zc - 3);
          else set.push(18, zc - 11);
          i += zc * 2 - 2;
        } else if (l == prv && nxt == l && nnxt == l) {
          var lz = i + 5;
          while (lz + 2 < len && tree[lz + 2] == l) lz += 2;
          var zc = Math.min(lz + 1 - i >>> 1, 6);
          set.push(16, zc - 3);
          i += zc * 2 - 2;
        } else set.push(l, 0);
      }
      return len >>> 1;
    };
    UZIP2.F._hufTree = function(hst, tree, MAXL) {
      var list = [], hl = hst.length, tl = tree.length, i = 0;
      for (i = 0; i < tl; i += 2) {
        tree[i] = 0;
        tree[i + 1] = 0;
      }
      for (i = 0; i < hl; i++) if (hst[i] != 0) list.push({ lit: i, f: hst[i] });
      var end = list.length, l2 = list.slice(0);
      if (end == 0) return 0;
      if (end == 1) {
        var lit = list[0].lit, l2 = lit == 0 ? 1 : 0;
        tree[(lit << 1) + 1] = 1;
        tree[(l2 << 1) + 1] = 1;
        return 1;
      }
      list.sort(function(a2, b2) {
        return a2.f - b2.f;
      });
      var a = list[0], b = list[1], i0 = 0, i1 = 1, i2 = 2;
      list[0] = { lit: -1, f: a.f + b.f, l: a, r: b, d: 0 };
      while (i1 != end - 1) {
        if (i0 != i1 && (i2 == end || list[i0].f < list[i2].f)) {
          a = list[i0++];
        } else {
          a = list[i2++];
        }
        if (i0 != i1 && (i2 == end || list[i0].f < list[i2].f)) {
          b = list[i0++];
        } else {
          b = list[i2++];
        }
        list[i1++] = { lit: -1, f: a.f + b.f, l: a, r: b };
      }
      var maxl = UZIP2.F.setDepth(list[i1 - 1], 0);
      if (maxl > MAXL) {
        UZIP2.F.restrictDepth(l2, MAXL, maxl);
        maxl = MAXL;
      }
      for (i = 0; i < end; i++) tree[(l2[i].lit << 1) + 1] = l2[i].d;
      return maxl;
    };
    UZIP2.F.setDepth = function(t, d) {
      if (t.lit != -1) {
        t.d = d;
        return d;
      }
      return Math.max(UZIP2.F.setDepth(t.l, d + 1), UZIP2.F.setDepth(t.r, d + 1));
    };
    UZIP2.F.restrictDepth = function(dps, MD, maxl) {
      var i = 0, bCost = 1 << maxl - MD, dbt = 0;
      dps.sort(function(a, b) {
        return b.d == a.d ? a.f - b.f : b.d - a.d;
      });
      for (i = 0; i < dps.length; i++) if (dps[i].d > MD) {
        var od = dps[i].d;
        dps[i].d = MD;
        dbt += bCost - (1 << maxl - od);
      } else break;
      dbt = dbt >>> maxl - MD;
      while (dbt > 0) {
        var od = dps[i].d;
        if (od < MD) {
          dps[i].d++;
          dbt -= 1 << MD - od - 1;
        } else i++;
      }
      for (; i >= 0; i--) if (dps[i].d == MD && dbt < 0) {
        dps[i].d--;
        dbt++;
      }
      if (dbt != 0) console.log("debt left");
    };
    UZIP2.F._goodIndex = function(v, arr) {
      var i = 0;
      if (arr[i | 16] <= v) i |= 16;
      if (arr[i | 8] <= v) i |= 8;
      if (arr[i | 4] <= v) i |= 4;
      if (arr[i | 2] <= v) i |= 2;
      if (arr[i | 1] <= v) i |= 1;
      return i;
    };
    UZIP2.F._writeLit = function(ch, ltree, out, pos) {
      UZIP2.F._putsF(out, pos, ltree[ch << 1]);
      return pos + ltree[(ch << 1) + 1];
    };
    UZIP2.F.inflate = function(data, buf) {
      var u8 = Uint8Array;
      if (data[0] == 3 && data[1] == 0) return buf ? buf : new u8(0);
      var F = UZIP2.F, bitsF = F._bitsF, bitsE = F._bitsE, decodeTiny = F._decodeTiny, makeCodes = F.makeCodes, codes2map = F.codes2map, get17 = F._get17;
      var U = F.U;
      var noBuf = buf == null;
      if (noBuf) buf = new u8(data.length >>> 2 << 3);
      var BFINAL = 0, BTYPE = 0, HLIT = 0, HDIST = 0, HCLEN = 0, ML = 0, MD = 0;
      var off = 0, pos = 0;
      var lmap, dmap;
      while (BFINAL == 0) {
        BFINAL = bitsF(data, pos, 1);
        BTYPE = bitsF(data, pos + 1, 2);
        pos += 3;
        if (BTYPE == 0) {
          if ((pos & 7) != 0) pos += 8 - (pos & 7);
          var p8 = (pos >>> 3) + 4, len = data[p8 - 4] | data[p8 - 3] << 8;
          if (noBuf) buf = UZIP2.F._check(buf, off + len);
          buf.set(new u8(data.buffer, data.byteOffset + p8, len), off);
          pos = p8 + len << 3;
          off += len;
          continue;
        }
        if (noBuf) buf = UZIP2.F._check(buf, off + (1 << 17));
        if (BTYPE == 1) {
          lmap = U.flmap;
          dmap = U.fdmap;
          ML = (1 << 9) - 1;
          MD = (1 << 5) - 1;
        }
        if (BTYPE == 2) {
          HLIT = bitsE(data, pos, 5) + 257;
          HDIST = bitsE(data, pos + 5, 5) + 1;
          HCLEN = bitsE(data, pos + 10, 4) + 4;
          pos += 14;
          var ppos = pos;
          for (var i = 0; i < 38; i += 2) {
            U.itree[i] = 0;
            U.itree[i + 1] = 0;
          }
          var tl = 1;
          for (var i = 0; i < HCLEN; i++) {
            var l = bitsE(data, pos + i * 3, 3);
            U.itree[(U.ordr[i] << 1) + 1] = l;
            if (l > tl) tl = l;
          }
          pos += 3 * HCLEN;
          makeCodes(U.itree, tl);
          codes2map(U.itree, tl, U.imap);
          lmap = U.lmap;
          dmap = U.dmap;
          pos = decodeTiny(U.imap, (1 << tl) - 1, HLIT + HDIST, data, pos, U.ttree);
          var mx0 = F._copyOut(U.ttree, 0, HLIT, U.ltree);
          ML = (1 << mx0) - 1;
          var mx1 = F._copyOut(U.ttree, HLIT, HDIST, U.dtree);
          MD = (1 << mx1) - 1;
          makeCodes(U.ltree, mx0);
          codes2map(U.ltree, mx0, lmap);
          makeCodes(U.dtree, mx1);
          codes2map(U.dtree, mx1, dmap);
        }
        while (true) {
          var code = lmap[get17(data, pos) & ML];
          pos += code & 15;
          var lit = code >>> 4;
          if (lit >>> 8 == 0) {
            buf[off++] = lit;
          } else if (lit == 256) {
            break;
          } else {
            var end = off + lit - 254;
            if (lit > 264) {
              var ebs = U.ldef[lit - 257];
              end = off + (ebs >>> 3) + bitsE(data, pos, ebs & 7);
              pos += ebs & 7;
            }
            var dcode = dmap[get17(data, pos) & MD];
            pos += dcode & 15;
            var dlit = dcode >>> 4;
            var dbs = U.ddef[dlit], dst = (dbs >>> 4) + bitsF(data, pos, dbs & 15);
            pos += dbs & 15;
            while (off < end) {
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
              buf[off] = buf[off++ - dst];
            }
            off = end;
          }
        }
      }
      return buf.length == off ? buf : buf.slice(0, off);
    };
    UZIP2.F._check = function(buf, len) {
      var bl = buf.length;
      if (len <= bl) return buf;
      var nbuf = new Uint8Array(Math.max(bl << 1, len));
      nbuf.set(buf, 0);
      return nbuf;
    };
    UZIP2.F._decodeTiny = function(lmap, LL, len, data, pos, tree) {
      var bitsE = UZIP2.F._bitsE, get17 = UZIP2.F._get17;
      var i = 0;
      while (i < len) {
        var code = lmap[get17(data, pos) & LL];
        pos += code & 15;
        var lit = code >>> 4;
        if (lit <= 15) {
          tree[i] = lit;
          i++;
        } else {
          var ll = 0, n = 0;
          if (lit == 16) {
            n = 3 + bitsE(data, pos, 2);
            pos += 2;
            ll = tree[i - 1];
          } else if (lit == 17) {
            n = 3 + bitsE(data, pos, 3);
            pos += 3;
          } else if (lit == 18) {
            n = 11 + bitsE(data, pos, 7);
            pos += 7;
          }
          var ni = i + n;
          while (i < ni) {
            tree[i] = ll;
            i++;
          }
        }
      }
      return pos;
    };
    UZIP2.F._copyOut = function(src, off, len, tree) {
      var mx = 0, i = 0, tl = tree.length >>> 1;
      while (i < len) {
        var v = src[i + off];
        tree[i << 1] = 0;
        tree[(i << 1) + 1] = v;
        if (v > mx) mx = v;
        i++;
      }
      while (i < tl) {
        tree[i << 1] = 0;
        tree[(i << 1) + 1] = 0;
        i++;
      }
      return mx;
    };
    UZIP2.F.makeCodes = function(tree, MAX_BITS) {
      var U = UZIP2.F.U;
      var max_code = tree.length;
      var code, bits, n, i, len;
      var bl_count = U.bl_count;
      for (var i = 0; i <= MAX_BITS; i++) bl_count[i] = 0;
      for (i = 1; i < max_code; i += 2) bl_count[tree[i]]++;
      var next_code = U.next_code;
      code = 0;
      bl_count[0] = 0;
      for (bits = 1; bits <= MAX_BITS; bits++) {
        code = code + bl_count[bits - 1] << 1;
        next_code[bits] = code;
      }
      for (n = 0; n < max_code; n += 2) {
        len = tree[n + 1];
        if (len != 0) {
          tree[n] = next_code[len];
          next_code[len]++;
        }
      }
    };
    UZIP2.F.codes2map = function(tree, MAX_BITS, map) {
      var max_code = tree.length;
      var U = UZIP2.F.U, r15 = U.rev15;
      for (var i = 0; i < max_code; i += 2) if (tree[i + 1] != 0) {
        var lit = i >> 1;
        var cl = tree[i + 1], val = lit << 4 | cl;
        var rest = MAX_BITS - cl, i0 = tree[i] << rest, i1 = i0 + (1 << rest);
        while (i0 != i1) {
          var p0 = r15[i0] >>> 15 - MAX_BITS;
          map[p0] = val;
          i0++;
        }
      }
    };
    UZIP2.F.revCodes = function(tree, MAX_BITS) {
      var r15 = UZIP2.F.U.rev15, imb = 15 - MAX_BITS;
      for (var i = 0; i < tree.length; i += 2) {
        var i0 = tree[i] << MAX_BITS - tree[i + 1];
        tree[i] = r15[i0] >>> imb;
      }
    };
    UZIP2.F._putsE = function(dt, pos, val) {
      val = val << (pos & 7);
      var o = pos >>> 3;
      dt[o] |= val;
      dt[o + 1] |= val >>> 8;
    };
    UZIP2.F._putsF = function(dt, pos, val) {
      val = val << (pos & 7);
      var o = pos >>> 3;
      dt[o] |= val;
      dt[o + 1] |= val >>> 8;
      dt[o + 2] |= val >>> 16;
    };
    UZIP2.F._bitsE = function(dt, pos, length) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8) >>> (pos & 7) & (1 << length) - 1;
    };
    UZIP2.F._bitsF = function(dt, pos, length) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16) >>> (pos & 7) & (1 << length) - 1;
    };
    UZIP2.F._get17 = function(dt, pos) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16) >>> (pos & 7);
    };
    UZIP2.F._get25 = function(dt, pos) {
      return (dt[pos >>> 3] | dt[(pos >>> 3) + 1] << 8 | dt[(pos >>> 3) + 2] << 16 | dt[(pos >>> 3) + 3] << 24) >>> (pos & 7);
    };
    UZIP2.F.U = function() {
      var u16 = Uint16Array, u32 = Uint32Array;
      return {
        next_code: new u16(16),
        bl_count: new u16(16),
        ordr: [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15],
        of0: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 999, 999, 999],
        exb: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0],
        ldef: new u16(32),
        df0: [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 65535, 65535],
        dxb: [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0],
        ddef: new u32(32),
        flmap: new u16(512),
        fltree: [],
        fdmap: new u16(32),
        fdtree: [],
        lmap: new u16(32768),
        ltree: [],
        ttree: [],
        dmap: new u16(32768),
        dtree: [],
        imap: new u16(512),
        itree: [],
        //rev9 : new u16(  512)
        rev15: new u16(1 << 15),
        lhst: new u32(286),
        dhst: new u32(30),
        ihst: new u32(19),
        lits: new u32(15e3),
        strt: new u16(1 << 16),
        prev: new u16(1 << 15)
      };
    }();
    (function() {
      var U = UZIP2.F.U;
      var len = 1 << 15;
      for (var i = 0; i < len; i++) {
        var x = i;
        x = (x & 2863311530) >>> 1 | (x & 1431655765) << 1;
        x = (x & 3435973836) >>> 2 | (x & 858993459) << 2;
        x = (x & 4042322160) >>> 4 | (x & 252645135) << 4;
        x = (x & 4278255360) >>> 8 | (x & 16711935) << 8;
        U.rev15[i] = (x >>> 16 | x << 16) >>> 17;
      }
      function pushV(tgt, n, sv) {
        while (n-- != 0) tgt.push(0, sv);
      }
      for (var i = 0; i < 32; i++) {
        U.ldef[i] = U.of0[i] << 3 | U.exb[i];
        U.ddef[i] = U.df0[i] << 4 | U.dxb[i];
      }
      pushV(U.fltree, 144, 8);
      pushV(U.fltree, 255 - 143, 9);
      pushV(U.fltree, 279 - 255, 7);
      pushV(U.fltree, 287 - 279, 8);
      UZIP2.F.makeCodes(U.fltree, 9);
      UZIP2.F.codes2map(U.fltree, 9, U.flmap);
      UZIP2.F.revCodes(U.fltree, 9);
      pushV(U.fdtree, 32, 5);
      UZIP2.F.makeCodes(U.fdtree, 5);
      UZIP2.F.codes2map(U.fdtree, 5, U.fdmap);
      UZIP2.F.revCodes(U.fdtree, 5);
      pushV(U.itree, 19, 0);
      pushV(U.ltree, 286, 0);
      pushV(U.dtree, 30, 0);
      pushV(U.ttree, 320, 0);
    })();
    if (typeof module2 !== "undefined" && typeof module2.exports !== "undefined") module2.exports = UZIP2;
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/UPNG.js
var require_UPNG = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/lib/UPNG.js"(exports2, module2) {
    (function() {
      var UPNG = {};
      if (typeof module2 == "object") {
        module2.exports = UPNG;
      } else {
        window.UPNG = UPNG;
      }
      if (typeof require == "function") {
        UZIP = require_UZIP();
      } else {
        UZIP = window.UZIP;
      }
      function log() {
        if (typeof process == "undefined" || process.env.NODE_ENV == "development") console.log.apply(console, arguments);
      }
      (function(UPNG2, UZIP2) {
        UPNG2.toRGBA8 = function(out) {
          var w = out.width, h = out.height;
          if (out.tabs.acTL == null) return [UPNG2.toRGBA8.decodeImage(out.data, w, h, out).buffer];
          var frms = [];
          if (out.frames[0].data == null) out.frames[0].data = out.data;
          var len = w * h * 4, img = new Uint8Array(len), empty = new Uint8Array(len), prev = new Uint8Array(len);
          for (var i = 0; i < out.frames.length; i++) {
            var frm = out.frames[i];
            var fx = frm.rect.x, fy = frm.rect.y, fw = frm.rect.width, fh = frm.rect.height;
            var fdata = UPNG2.toRGBA8.decodeImage(frm.data, fw, fh, out);
            if (i != 0) for (var j = 0; j < len; j++) prev[j] = img[j];
            if (frm.blend == 0) UPNG2._copyTile(fdata, fw, fh, img, w, h, fx, fy, 0);
            else if (frm.blend == 1) UPNG2._copyTile(fdata, fw, fh, img, w, h, fx, fy, 1);
            frms.push(img.buffer.slice(0));
            if (frm.dispose == 0) {
            } else if (frm.dispose == 1) UPNG2._copyTile(empty, fw, fh, img, w, h, fx, fy, 0);
            else if (frm.dispose == 2) for (var j = 0; j < len; j++) img[j] = prev[j];
          }
          return frms;
        };
        UPNG2.toRGBA8.decodeImage = function(data, w, h, out) {
          var area = w * h, bpp = UPNG2.decode._getBPP(out);
          var bpl = Math.ceil(w * bpp / 8);
          var bf = new Uint8Array(area * 4), bf32 = new Uint32Array(bf.buffer);
          var ctype = out.ctype, depth = out.depth;
          var rs = UPNG2._bin.readUshort;
          var time = Date.now();
          if (ctype == 6) {
            var qarea = area << 2;
            if (depth == 8) for (var i = 0; i < qarea; i++) {
              bf[i] = data[i];
            }
            if (depth == 16) for (var i = 0; i < qarea; i++) {
              bf[i] = data[i << 1];
            }
          } else if (ctype == 2) {
            var ts = out.tabs["tRNS"];
            if (ts == null) {
              if (depth == 8) for (var i = 0; i < area; i++) {
                var ti = i * 3;
                bf32[i] = 255 << 24 | data[ti + 2] << 16 | data[ti + 1] << 8 | data[ti];
              }
              if (depth == 16) for (var i = 0; i < area; i++) {
                var ti = i * 6;
                bf32[i] = 255 << 24 | data[ti + 4] << 16 | data[ti + 2] << 8 | data[ti];
              }
            } else {
              var tr = ts[0], tg = ts[1], tb = ts[2];
              if (depth == 8) for (var i = 0; i < area; i++) {
                var qi = i << 2, ti = i * 3;
                bf32[i] = 255 << 24 | data[ti + 2] << 16 | data[ti + 1] << 8 | data[ti];
                if (data[ti] == tr && data[ti + 1] == tg && data[ti + 2] == tb) bf[qi + 3] = 0;
              }
              if (depth == 16) for (var i = 0; i < area; i++) {
                var qi = i << 2, ti = i * 6;
                bf32[i] = 255 << 24 | data[ti + 4] << 16 | data[ti + 2] << 8 | data[ti];
                if (rs(data, ti) == tr && rs(data, ti + 2) == tg && rs(data, ti + 4) == tb) bf[qi + 3] = 0;
              }
            }
          } else if (ctype == 3) {
            var p = out.tabs["PLTE"], ap = out.tabs["tRNS"], tl = ap ? ap.length : 0;
            if (depth == 1) for (var y = 0; y < h; y++) {
              var s0 = y * bpl, t0 = y * w;
              for (var i = 0; i < w; i++) {
                var qi = t0 + i << 2, j = data[s0 + (i >> 3)] >> 7 - ((i & 7) << 0) & 1, cj = 3 * j;
                bf[qi] = p[cj];
                bf[qi + 1] = p[cj + 1];
                bf[qi + 2] = p[cj + 2];
                bf[qi + 3] = j < tl ? ap[j] : 255;
              }
            }
            if (depth == 2) for (var y = 0; y < h; y++) {
              var s0 = y * bpl, t0 = y * w;
              for (var i = 0; i < w; i++) {
                var qi = t0 + i << 2, j = data[s0 + (i >> 2)] >> 6 - ((i & 3) << 1) & 3, cj = 3 * j;
                bf[qi] = p[cj];
                bf[qi + 1] = p[cj + 1];
                bf[qi + 2] = p[cj + 2];
                bf[qi + 3] = j < tl ? ap[j] : 255;
              }
            }
            if (depth == 4) for (var y = 0; y < h; y++) {
              var s0 = y * bpl, t0 = y * w;
              for (var i = 0; i < w; i++) {
                var qi = t0 + i << 2, j = data[s0 + (i >> 1)] >> 4 - ((i & 1) << 2) & 15, cj = 3 * j;
                bf[qi] = p[cj];
                bf[qi + 1] = p[cj + 1];
                bf[qi + 2] = p[cj + 2];
                bf[qi + 3] = j < tl ? ap[j] : 255;
              }
            }
            if (depth == 8) for (var i = 0; i < area; i++) {
              var qi = i << 2, j = data[i], cj = 3 * j;
              bf[qi] = p[cj];
              bf[qi + 1] = p[cj + 1];
              bf[qi + 2] = p[cj + 2];
              bf[qi + 3] = j < tl ? ap[j] : 255;
            }
          } else if (ctype == 4) {
            if (depth == 8) for (var i = 0; i < area; i++) {
              var qi = i << 2, di = i << 1, gr = data[di];
              bf[qi] = gr;
              bf[qi + 1] = gr;
              bf[qi + 2] = gr;
              bf[qi + 3] = data[di + 1];
            }
            if (depth == 16) for (var i = 0; i < area; i++) {
              var qi = i << 2, di = i << 2, gr = data[di];
              bf[qi] = gr;
              bf[qi + 1] = gr;
              bf[qi + 2] = gr;
              bf[qi + 3] = data[di + 2];
            }
          } else if (ctype == 0) {
            var tr = out.tabs["tRNS"] ? out.tabs["tRNS"] : -1;
            for (var y = 0; y < h; y++) {
              var off = y * bpl, to = y * w;
              if (depth == 1) for (var x = 0; x < w; x++) {
                var gr = 255 * (data[off + (x >>> 3)] >>> 7 - (x & 7) & 1), al = gr == tr * 255 ? 0 : 255;
                bf32[to + x] = al << 24 | gr << 16 | gr << 8 | gr;
              }
              else if (depth == 2) for (var x = 0; x < w; x++) {
                var gr = 85 * (data[off + (x >>> 2)] >>> 6 - ((x & 3) << 1) & 3), al = gr == tr * 85 ? 0 : 255;
                bf32[to + x] = al << 24 | gr << 16 | gr << 8 | gr;
              }
              else if (depth == 4) for (var x = 0; x < w; x++) {
                var gr = 17 * (data[off + (x >>> 1)] >>> 4 - ((x & 1) << 2) & 15), al = gr == tr * 17 ? 0 : 255;
                bf32[to + x] = al << 24 | gr << 16 | gr << 8 | gr;
              }
              else if (depth == 8) for (var x = 0; x < w; x++) {
                var gr = data[off + x], al = gr == tr ? 0 : 255;
                bf32[to + x] = al << 24 | gr << 16 | gr << 8 | gr;
              }
              else if (depth == 16) for (var x = 0; x < w; x++) {
                var gr = data[off + (x << 1)], al = rs(data, off + (x << i)) == tr ? 0 : 255;
                bf32[to + x] = al << 24 | gr << 16 | gr << 8 | gr;
              }
            }
          }
          return bf;
        };
        UPNG2.decode = function(buff) {
          var data = new Uint8Array(buff), offset = 8, bin = UPNG2._bin, rUs = bin.readUshort, rUi = bin.readUint;
          var out = { tabs: {}, frames: [] };
          var dd = new Uint8Array(data.length), doff = 0;
          var fd, foff = 0;
          var mgck = [137, 80, 78, 71, 13, 10, 26, 10];
          for (var i = 0; i < 8; i++) if (data[i] != mgck[i]) throw "The input is not a PNG file!";
          while (offset < data.length) {
            var len = bin.readUint(data, offset);
            offset += 4;
            var type = bin.readASCII(data, offset, 4);
            offset += 4;
            if (type == "IHDR") {
              UPNG2.decode._IHDR(data, offset, out);
            } else if (type == "IDAT") {
              for (var i = 0; i < len; i++) dd[doff + i] = data[offset + i];
              doff += len;
            } else if (type == "acTL") {
              out.tabs[type] = { num_frames: rUi(data, offset), num_plays: rUi(data, offset + 4) };
              fd = new Uint8Array(data.length);
            } else if (type == "fcTL") {
              if (foff != 0) {
                var fr = out.frames[out.frames.length - 1];
                fr.data = UPNG2.decode._decompress(out, fd.slice(0, foff), fr.rect.width, fr.rect.height);
                foff = 0;
              }
              var rct = { x: rUi(data, offset + 12), y: rUi(data, offset + 16), width: rUi(data, offset + 4), height: rUi(data, offset + 8) };
              var del = rUs(data, offset + 22);
              del = rUs(data, offset + 20) / (del == 0 ? 100 : del);
              var frm = { rect: rct, delay: Math.round(del * 1e3), dispose: data[offset + 24], blend: data[offset + 25] };
              out.frames.push(frm);
            } else if (type == "fdAT") {
              for (var i = 0; i < len - 4; i++) fd[foff + i] = data[offset + i + 4];
              foff += len - 4;
            } else if (type == "pHYs") {
              out.tabs[type] = [bin.readUint(data, offset), bin.readUint(data, offset + 4), data[offset + 8]];
            } else if (type == "cHRM") {
              out.tabs[type] = [];
              for (var i = 0; i < 8; i++) out.tabs[type].push(bin.readUint(data, offset + i * 4));
            } else if (type == "tEXt") {
              if (out.tabs[type] == null) out.tabs[type] = {};
              var nz = bin.nextZero(data, offset);
              var keyw = bin.readASCII(data, offset, nz - offset);
              var text = bin.readASCII(data, nz + 1, offset + len - nz - 1);
              out.tabs[type][keyw] = text;
            } else if (type == "iTXt") {
              if (out.tabs[type] == null) out.tabs[type] = {};
              var nz = 0, off = offset;
              nz = bin.nextZero(data, off);
              var keyw = bin.readASCII(data, off, nz - off);
              off = nz + 1;
              var cflag = data[off], cmeth = data[off + 1];
              off += 2;
              nz = bin.nextZero(data, off);
              var ltag = bin.readASCII(data, off, nz - off);
              off = nz + 1;
              nz = bin.nextZero(data, off);
              var tkeyw = bin.readUTF8(data, off, nz - off);
              off = nz + 1;
              var text = bin.readUTF8(data, off, len - (off - offset));
              out.tabs[type][keyw] = text;
            } else if (type == "PLTE") {
              out.tabs[type] = bin.readBytes(data, offset, len);
            } else if (type == "hIST") {
              var pl = out.tabs["PLTE"].length / 3;
              out.tabs[type] = [];
              for (var i = 0; i < pl; i++) out.tabs[type].push(rUs(data, offset + i * 2));
            } else if (type == "tRNS") {
              if (out.ctype == 3) out.tabs[type] = bin.readBytes(data, offset, len);
              else if (out.ctype == 0) out.tabs[type] = rUs(data, offset);
              else if (out.ctype == 2) out.tabs[type] = [rUs(data, offset), rUs(data, offset + 2), rUs(data, offset + 4)];
            } else if (type == "gAMA") out.tabs[type] = bin.readUint(data, offset) / 1e5;
            else if (type == "sRGB") out.tabs[type] = data[offset];
            else if (type == "bKGD") {
              if (out.ctype == 0 || out.ctype == 4) out.tabs[type] = [rUs(data, offset)];
              else if (out.ctype == 2 || out.ctype == 6) out.tabs[type] = [rUs(data, offset), rUs(data, offset + 2), rUs(data, offset + 4)];
              else if (out.ctype == 3) out.tabs[type] = data[offset];
            } else if (type == "IEND") {
              break;
            }
            offset += len;
            var crc = bin.readUint(data, offset);
            offset += 4;
          }
          if (foff != 0) {
            var fr = out.frames[out.frames.length - 1];
            fr.data = UPNG2.decode._decompress(out, fd.slice(0, foff), fr.rect.width, fr.rect.height);
            foff = 0;
          }
          out.data = UPNG2.decode._decompress(out, dd, out.width, out.height);
          delete out.compress;
          delete out.interlace;
          delete out.filter;
          return out;
        };
        UPNG2.decode._decompress = function(out, dd, w, h) {
          var time = Date.now();
          var bpp = UPNG2.decode._getBPP(out), bpl = Math.ceil(w * bpp / 8), buff = new Uint8Array((bpl + 1 + out.interlace) * h);
          dd = UPNG2.decode._inflate(dd, buff);
          var time = Date.now();
          if (out.interlace == 0) dd = UPNG2.decode._filterZero(dd, out, 0, w, h);
          else if (out.interlace == 1) dd = UPNG2.decode._readInterlace(dd, out);
          return dd;
        };
        UPNG2.decode._inflate = function(data, buff) {
          var out = UPNG2["inflateRaw"](new Uint8Array(data.buffer, 2, data.length - 6), buff);
          return out;
        };
        UPNG2.inflateRaw = function() {
          var H = {};
          H.H = {};
          H.H.N = function(N, W) {
            var R = Uint8Array, i = 0, m = 0, J = 0, h = 0, Q = 0, X = 0, u = 0, w = 0, d = 0, v, C;
            if (N[0] == 3 && N[1] == 0) return W ? W : new R(0);
            var V = H.H, n = V.b, A = V.e, l = V.R, M = V.n, I = V.A, e = V.Z, b = V.m, Z = W == null;
            if (Z) W = new R(N.length >>> 2 << 3);
            while (i == 0) {
              i = n(N, d, 1);
              m = n(N, d + 1, 2);
              d += 3;
              if (m == 0) {
                if ((d & 7) != 0) d += 8 - (d & 7);
                var D = (d >>> 3) + 4, q = N[D - 4] | N[D - 3] << 8;
                if (Z) W = H.H.W(W, w + q);
                W.set(new R(N.buffer, N.byteOffset + D, q), w);
                d = D + q << 3;
                w += q;
                continue;
              }
              if (Z) W = H.H.W(W, w + (1 << 17));
              if (m == 1) {
                v = b.J;
                C = b.h;
                X = (1 << 9) - 1;
                u = (1 << 5) - 1;
              }
              if (m == 2) {
                J = A(N, d, 5) + 257;
                h = A(N, d + 5, 5) + 1;
                Q = A(N, d + 10, 4) + 4;
                d += 14;
                var E = d, j = 1;
                for (var c = 0; c < 38; c += 2) {
                  b.Q[c] = 0;
                  b.Q[c + 1] = 0;
                }
                for (var c = 0; c < Q; c++) {
                  var K = A(N, d + c * 3, 3);
                  b.Q[(b.X[c] << 1) + 1] = K;
                  if (K > j) j = K;
                }
                d += 3 * Q;
                M(b.Q, j);
                I(b.Q, j, b.u);
                v = b.w;
                C = b.d;
                d = l(b.u, (1 << j) - 1, J + h, N, d, b.v);
                var r = V.V(b.v, 0, J, b.C);
                X = (1 << r) - 1;
                var S = V.V(b.v, J, h, b.D);
                u = (1 << S) - 1;
                M(b.C, r);
                I(b.C, r, v);
                M(b.D, S);
                I(b.D, S, C);
              }
              while (true) {
                var T = v[e(N, d) & X];
                d += T & 15;
                var p = T >>> 4;
                if (p >>> 8 == 0) {
                  W[w++] = p;
                } else if (p == 256) {
                  break;
                } else {
                  var z = w + p - 254;
                  if (p > 264) {
                    var _ = b.q[p - 257];
                    z = w + (_ >>> 3) + A(N, d, _ & 7);
                    d += _ & 7;
                  }
                  var $ = C[e(N, d) & u];
                  d += $ & 15;
                  var s = $ >>> 4, Y = b.c[s], a = (Y >>> 4) + n(N, d, Y & 15);
                  d += Y & 15;
                  while (w < z) {
                    W[w] = W[w++ - a];
                    W[w] = W[w++ - a];
                    W[w] = W[w++ - a];
                    W[w] = W[w++ - a];
                  }
                  w = z;
                }
              }
            }
            return W.length == w ? W : W.slice(0, w);
          };
          H.H.W = function(N, W) {
            var R = N.length;
            if (W <= R) return N;
            var V = new Uint8Array(R << 1);
            V.set(N, 0);
            return V;
          };
          H.H.R = function(N, W, R, V, n, A) {
            var l = H.H.e, M = H.H.Z, I = 0;
            while (I < R) {
              var e = N[M(V, n) & W];
              n += e & 15;
              var b = e >>> 4;
              if (b <= 15) {
                A[I] = b;
                I++;
              } else {
                var Z = 0, m = 0;
                if (b == 16) {
                  m = 3 + l(V, n, 2);
                  n += 2;
                  Z = A[I - 1];
                } else if (b == 17) {
                  m = 3 + l(V, n, 3);
                  n += 3;
                } else if (b == 18) {
                  m = 11 + l(V, n, 7);
                  n += 7;
                }
                var J = I + m;
                while (I < J) {
                  A[I] = Z;
                  I++;
                }
              }
            }
            return n;
          };
          H.H.V = function(N, W, R, V) {
            var n = 0, A = 0, l = V.length >>> 1;
            while (A < R) {
              var M = N[A + W];
              V[A << 1] = 0;
              V[(A << 1) + 1] = M;
              if (M > n) n = M;
              A++;
            }
            while (A < l) {
              V[A << 1] = 0;
              V[(A << 1) + 1] = 0;
              A++;
            }
            return n;
          };
          H.H.n = function(N, W) {
            var R = H.H.m, V = N.length, n, A, l, M, I, e = R.j;
            for (var M = 0; M <= W; M++) e[M] = 0;
            for (M = 1; M < V; M += 2) e[N[M]]++;
            var b = R.K;
            n = 0;
            e[0] = 0;
            for (A = 1; A <= W; A++) {
              n = n + e[A - 1] << 1;
              b[A] = n;
            }
            for (l = 0; l < V; l += 2) {
              I = N[l + 1];
              if (I != 0) {
                N[l] = b[I];
                b[I]++;
              }
            }
          };
          H.H.A = function(N, W, R) {
            var V = N.length, n = H.H.m, A = n.r;
            for (var l = 0; l < V; l += 2) if (N[l + 1] != 0) {
              var M = l >> 1, I = N[l + 1], e = M << 4 | I, b = W - I, Z = N[l] << b, m = Z + (1 << b);
              while (Z != m) {
                var J = A[Z] >>> 15 - W;
                R[J] = e;
                Z++;
              }
            }
          };
          H.H.l = function(N, W) {
            var R = H.H.m.r, V = 15 - W;
            for (var n = 0; n < N.length; n += 2) {
              var A = N[n] << W - N[n + 1];
              N[n] = R[A] >>> V;
            }
          };
          H.H.M = function(N, W, R) {
            R = R << (W & 7);
            var V = W >>> 3;
            N[V] |= R;
            N[V + 1] |= R >>> 8;
          };
          H.H.I = function(N, W, R) {
            R = R << (W & 7);
            var V = W >>> 3;
            N[V] |= R;
            N[V + 1] |= R >>> 8;
            N[V + 2] |= R >>> 16;
          };
          H.H.e = function(N, W, R) {
            return (N[W >>> 3] | N[(W >>> 3) + 1] << 8) >>> (W & 7) & (1 << R) - 1;
          };
          H.H.b = function(N, W, R) {
            return (N[W >>> 3] | N[(W >>> 3) + 1] << 8 | N[(W >>> 3) + 2] << 16) >>> (W & 7) & (1 << R) - 1;
          };
          H.H.Z = function(N, W) {
            return (N[W >>> 3] | N[(W >>> 3) + 1] << 8 | N[(W >>> 3) + 2] << 16) >>> (W & 7);
          };
          H.H.i = function(N, W) {
            return (N[W >>> 3] | N[(W >>> 3) + 1] << 8 | N[(W >>> 3) + 2] << 16 | N[(W >>> 3) + 3] << 24) >>> (W & 7);
          };
          H.H.m = function() {
            var N = Uint16Array, W = Uint32Array;
            return { K: new N(16), j: new N(16), X: [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15], S: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 999, 999, 999], T: [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0], q: new N(32), p: [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 65535, 65535], z: [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0], c: new W(32), J: new N(512), _: [], h: new N(32), $: [], w: new N(32768), C: [], v: [], d: new N(32768), D: [], u: new N(512), Q: [], r: new N(1 << 15), s: new W(286), Y: new W(30), a: new W(19), t: new W(15e3), k: new N(1 << 16), g: new N(1 << 15) };
          }();
          (function() {
            var N = H.H.m, W = 1 << 15;
            for (var R = 0; R < W; R++) {
              var V = R;
              V = (V & 2863311530) >>> 1 | (V & 1431655765) << 1;
              V = (V & 3435973836) >>> 2 | (V & 858993459) << 2;
              V = (V & 4042322160) >>> 4 | (V & 252645135) << 4;
              V = (V & 4278255360) >>> 8 | (V & 16711935) << 8;
              N.r[R] = (V >>> 16 | V << 16) >>> 17;
            }
            function n(A, l, M) {
              while (l-- != 0) A.push(0, M);
            }
            for (var R = 0; R < 32; R++) {
              N.q[R] = N.S[R] << 3 | N.T[R];
              N.c[R] = N.p[R] << 4 | N.z[R];
            }
            n(N._, 144, 8);
            n(N._, 255 - 143, 9);
            n(N._, 279 - 255, 7);
            n(N._, 287 - 279, 8);
            H.H.n(N._, 9);
            H.H.A(N._, 9, N.J);
            H.H.l(N._, 9);
            n(N.$, 32, 5);
            H.H.n(N.$, 5);
            H.H.A(N.$, 5, N.h);
            H.H.l(N.$, 5);
            n(N.Q, 19, 0);
            n(N.C, 286, 0);
            n(N.D, 30, 0);
            n(N.v, 320, 0);
          })();
          return H.H.N;
        }();
        UPNG2.decode._readInterlace = function(data, out) {
          var w = out.width, h = out.height;
          var bpp = UPNG2.decode._getBPP(out), cbpp = bpp >> 3, bpl = Math.ceil(w * bpp / 8);
          var img = new Uint8Array(h * bpl);
          var di = 0;
          var starting_row = [0, 0, 4, 0, 2, 0, 1];
          var starting_col = [0, 4, 0, 2, 0, 1, 0];
          var row_increment = [8, 8, 8, 4, 4, 2, 2];
          var col_increment = [8, 8, 4, 4, 2, 2, 1];
          var pass = 0;
          while (pass < 7) {
            var ri = row_increment[pass], ci = col_increment[pass];
            var sw = 0, sh = 0;
            var cr = starting_row[pass];
            while (cr < h) {
              cr += ri;
              sh++;
            }
            var cc = starting_col[pass];
            while (cc < w) {
              cc += ci;
              sw++;
            }
            var bpll = Math.ceil(sw * bpp / 8);
            UPNG2.decode._filterZero(data, out, di, sw, sh);
            var y = 0, row = starting_row[pass];
            while (row < h) {
              var col = starting_col[pass];
              var cdi = di + y * bpll << 3;
              while (col < w) {
                if (bpp == 1) {
                  var val = data[cdi >> 3];
                  val = val >> 7 - (cdi & 7) & 1;
                  img[row * bpl + (col >> 3)] |= val << 7 - ((col & 7) << 0);
                }
                if (bpp == 2) {
                  var val = data[cdi >> 3];
                  val = val >> 6 - (cdi & 7) & 3;
                  img[row * bpl + (col >> 2)] |= val << 6 - ((col & 3) << 1);
                }
                if (bpp == 4) {
                  var val = data[cdi >> 3];
                  val = val >> 4 - (cdi & 7) & 15;
                  img[row * bpl + (col >> 1)] |= val << 4 - ((col & 1) << 2);
                }
                if (bpp >= 8) {
                  var ii = row * bpl + col * cbpp;
                  for (var j = 0; j < cbpp; j++) img[ii + j] = data[(cdi >> 3) + j];
                }
                cdi += bpp;
                col += ci;
              }
              y++;
              row += ri;
            }
            if (sw * sh != 0) di += sh * (1 + bpll);
            pass = pass + 1;
          }
          return img;
        };
        UPNG2.decode._getBPP = function(out) {
          var noc = [1, null, 3, 1, 2, null, 4][out.ctype];
          return noc * out.depth;
        };
        UPNG2.decode._filterZero = function(data, out, off, w, h) {
          var bpp = UPNG2.decode._getBPP(out), bpl = Math.ceil(w * bpp / 8), paeth = UPNG2.decode._paeth;
          bpp = Math.ceil(bpp / 8);
          var i = 0, di = 1, type = 0, x = 0;
          for (var y = 0; y < h; y++) {
            i = off + y * bpl;
            di = i + y + 1;
            type = data[di - 1];
            x = 0;
            if (type == 0) for (; x < bpl; x++) data[i + x] = data[di + x];
            else if (type == 1) {
              for (; x < bpp; x++) data[i + x] = data[di + x];
              for (; x < bpl; x++) data[i + x] = data[di + x] + data[i + x - bpp] & 255;
            } else if (y == 0) {
              for (; x < bpp; x++) data[i + x] = data[di + x];
              if (type == 2) for (; x < bpl; x++) data[i + x] = data[di + x];
              else if (type == 3) for (; x < bpl; x++) data[i + x] = data[di + x] + (data[i + x - bpp] >>> 1) & 255;
              else if (type == 4) for (; x < bpl; x++) data[i + x] = data[di + x] + paeth(data[i + x - bpp], 0, 0) & 255;
            } else {
              if (type == 2) {
                for (; x < bpl; x++) data[i + x] = data[di + x] + data[i + x - bpl] & 255;
              } else if (type == 3) {
                for (; x < bpp; x++) data[i + x] = data[di + x] + (data[i + x - bpl] >>> 1) & 255;
                for (; x < bpl; x++) data[i + x] = data[di + x] + (data[i + x - bpl] + data[i + x - bpp] >>> 1) & 255;
              } else if (type == 4) {
                for (; x < bpp; x++) data[i + x] = data[di + x] + paeth(0, data[i + x - bpl], 0) & 255;
                for (; x < bpl; x++) data[i + x] = data[di + x] + paeth(data[i + x - bpp], data[i + x - bpl], data[i + x - bpp - bpl]) & 255;
              }
            }
          }
          return data;
        };
        UPNG2.decode._paeth = function(a, b, c) {
          var p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
          if (pa <= pb && pa <= pc) return a;
          else if (pb <= pc) return b;
          return c;
        };
        UPNG2.decode._IHDR = function(data, offset, out) {
          var bin = UPNG2._bin;
          out.width = bin.readUint(data, offset);
          offset += 4;
          out.height = bin.readUint(data, offset);
          offset += 4;
          out.depth = data[offset];
          offset++;
          out.ctype = data[offset];
          offset++;
          out.compress = data[offset];
          offset++;
          out.filter = data[offset];
          offset++;
          out.interlace = data[offset];
          offset++;
        };
        UPNG2._bin = {
          nextZero: function(data, p) {
            while (data[p] != 0) p++;
            return p;
          },
          readUshort: function(buff, p) {
            return buff[p] << 8 | buff[p + 1];
          },
          writeUshort: function(buff, p, n) {
            buff[p] = n >> 8 & 255;
            buff[p + 1] = n & 255;
          },
          readUint: function(buff, p) {
            return buff[p] * (256 * 256 * 256) + (buff[p + 1] << 16 | buff[p + 2] << 8 | buff[p + 3]);
          },
          writeUint: function(buff, p, n) {
            buff[p] = n >> 24 & 255;
            buff[p + 1] = n >> 16 & 255;
            buff[p + 2] = n >> 8 & 255;
            buff[p + 3] = n & 255;
          },
          readASCII: function(buff, p, l) {
            var s = "";
            for (var i = 0; i < l; i++) s += String.fromCharCode(buff[p + i]);
            return s;
          },
          writeASCII: function(data, p, s) {
            for (var i = 0; i < s.length; i++) data[p + i] = s.charCodeAt(i);
          },
          readBytes: function(buff, p, l) {
            var arr = [];
            for (var i = 0; i < l; i++) arr.push(buff[p + i]);
            return arr;
          },
          pad: function(n) {
            return n.length < 2 ? "0" + n : n;
          },
          readUTF8: function(buff, p, l) {
            var s = "", ns;
            for (var i = 0; i < l; i++) s += "%" + UPNG2._bin.pad(buff[p + i].toString(16));
            try {
              ns = decodeURIComponent(s);
            } catch (e) {
              return UPNG2._bin.readASCII(buff, p, l);
            }
            return ns;
          }
        };
        UPNG2._copyTile = function(sb, sw, sh, tb, tw, th, xoff, yoff, mode) {
          var w = Math.min(sw, tw), h = Math.min(sh, th);
          var si = 0, ti = 0;
          for (var y = 0; y < h; y++)
            for (var x = 0; x < w; x++) {
              if (xoff >= 0 && yoff >= 0) {
                si = y * sw + x << 2;
                ti = (yoff + y) * tw + xoff + x << 2;
              } else {
                si = (-yoff + y) * sw - xoff + x << 2;
                ti = y * tw + x << 2;
              }
              if (mode == 0) {
                tb[ti] = sb[si];
                tb[ti + 1] = sb[si + 1];
                tb[ti + 2] = sb[si + 2];
                tb[ti + 3] = sb[si + 3];
              } else if (mode == 1) {
                var fa = sb[si + 3] * (1 / 255), fr = sb[si] * fa, fg = sb[si + 1] * fa, fb = sb[si + 2] * fa;
                var ba = tb[ti + 3] * (1 / 255), br = tb[ti] * ba, bg = tb[ti + 1] * ba, bb = tb[ti + 2] * ba;
                var ifa = 1 - fa, oa = fa + ba * ifa, ioa = oa == 0 ? 0 : 1 / oa;
                tb[ti + 3] = 255 * oa;
                tb[ti + 0] = (fr + br * ifa) * ioa;
                tb[ti + 1] = (fg + bg * ifa) * ioa;
                tb[ti + 2] = (fb + bb * ifa) * ioa;
              } else if (mode == 2) {
                var fa = sb[si + 3], fr = sb[si], fg = sb[si + 1], fb = sb[si + 2];
                var ba = tb[ti + 3], br = tb[ti], bg = tb[ti + 1], bb = tb[ti + 2];
                if (fa == ba && fr == br && fg == bg && fb == bb) {
                  tb[ti] = 0;
                  tb[ti + 1] = 0;
                  tb[ti + 2] = 0;
                  tb[ti + 3] = 0;
                } else {
                  tb[ti] = fr;
                  tb[ti + 1] = fg;
                  tb[ti + 2] = fb;
                  tb[ti + 3] = fa;
                }
              } else if (mode == 3) {
                var fa = sb[si + 3], fr = sb[si], fg = sb[si + 1], fb = sb[si + 2];
                var ba = tb[ti + 3], br = tb[ti], bg = tb[ti + 1], bb = tb[ti + 2];
                if (fa == ba && fr == br && fg == bg && fb == bb) continue;
                if (fa < 220 && ba > 20) return false;
              }
            }
          return true;
        };
        UPNG2.encode = function(bufs, w, h, ps, dels, tabs, forbidPlte) {
          if (ps == null) ps = 0;
          if (forbidPlte == null) forbidPlte = false;
          var nimg = UPNG2.encode.compress(bufs, w, h, ps, [false, false, false, 0, forbidPlte]);
          UPNG2.encode.compressPNG(nimg, -1);
          return UPNG2.encode._main(nimg, w, h, dels, tabs);
        };
        UPNG2.encodeLL = function(bufs, w, h, cc, ac, depth, dels, tabs) {
          var nimg = { ctype: 0 + (cc == 1 ? 0 : 2) + (ac == 0 ? 0 : 4), depth, frames: [] };
          var bipp = (cc + ac) * depth, bipl = bipp * w;
          for (var i = 0; i < bufs.length; i++)
            nimg.frames.push({ rect: { x: 0, y: 0, width: w, height: h }, img: new Uint8Array(bufs[i]), blend: 0, dispose: 1, bpp: Math.ceil(bipp / 8), bpl: Math.ceil(bipl / 8) });
          UPNG2.encode.compressPNG(nimg, 4);
          return UPNG2.encode._main(nimg, w, h, dels, tabs);
        };
        UPNG2.encode._main = function(nimg, w, h, dels, tabs) {
          if (tabs == null) tabs = {};
          var crc = UPNG2.crc.crc, wUi = UPNG2._bin.writeUint, wUs = UPNG2._bin.writeUshort, wAs = UPNG2._bin.writeASCII;
          var offset = 8, anim = nimg.frames.length > 1, pltAlpha = false;
          var leng = 8 + (16 + 5 + 4) + (anim ? 20 : 0);
          if (tabs["sRGB"] != null) leng += 8 + 1 + 4;
          if (tabs["pHYs"] != null) leng += 8 + 9 + 4;
          if (nimg.ctype == 3) {
            var dl = nimg.plte.length;
            for (var i = 0; i < dl; i++) if (nimg.plte[i] >>> 24 != 255) pltAlpha = true;
            leng += 8 + dl * 3 + 4 + (pltAlpha ? 8 + dl * 1 + 4 : 0);
          }
          for (var j = 0; j < nimg.frames.length; j++) {
            var fr = nimg.frames[j];
            if (anim) leng += 38;
            leng += fr.cimg.length + 12;
            if (j != 0) leng += 4;
          }
          leng += 12;
          var data = new Uint8Array(leng);
          var wr = [137, 80, 78, 71, 13, 10, 26, 10];
          for (var i = 0; i < 8; i++) data[i] = wr[i];
          wUi(data, offset, 13);
          offset += 4;
          wAs(data, offset, "IHDR");
          offset += 4;
          wUi(data, offset, w);
          offset += 4;
          wUi(data, offset, h);
          offset += 4;
          data[offset] = nimg.depth;
          offset++;
          data[offset] = nimg.ctype;
          offset++;
          data[offset] = 0;
          offset++;
          data[offset] = 0;
          offset++;
          data[offset] = 0;
          offset++;
          wUi(data, offset, crc(data, offset - 17, 17));
          offset += 4;
          if (tabs["sRGB"] != null) {
            wUi(data, offset, 1);
            offset += 4;
            wAs(data, offset, "sRGB");
            offset += 4;
            data[offset] = tabs["sRGB"];
            offset++;
            wUi(data, offset, crc(data, offset - 5, 5));
            offset += 4;
          }
          if (tabs["pHYs"] != null) {
            wUi(data, offset, 9);
            offset += 4;
            wAs(data, offset, "pHYs");
            offset += 4;
            wUi(data, offset, tabs["pHYs"][0]);
            offset += 4;
            wUi(data, offset, tabs["pHYs"][1]);
            offset += 4;
            data[offset] = tabs["pHYs"][2];
            offset++;
            wUi(data, offset, crc(data, offset - 13, 13));
            offset += 4;
          }
          if (anim) {
            wUi(data, offset, 8);
            offset += 4;
            wAs(data, offset, "acTL");
            offset += 4;
            wUi(data, offset, nimg.frames.length);
            offset += 4;
            wUi(data, offset, tabs["loop"] != null ? tabs["loop"] : 0);
            offset += 4;
            wUi(data, offset, crc(data, offset - 12, 12));
            offset += 4;
          }
          if (nimg.ctype == 3) {
            var dl = nimg.plte.length;
            wUi(data, offset, dl * 3);
            offset += 4;
            wAs(data, offset, "PLTE");
            offset += 4;
            for (var i = 0; i < dl; i++) {
              var ti = i * 3, c = nimg.plte[i], r = c & 255, g = c >>> 8 & 255, b = c >>> 16 & 255;
              data[offset + ti + 0] = r;
              data[offset + ti + 1] = g;
              data[offset + ti + 2] = b;
            }
            offset += dl * 3;
            wUi(data, offset, crc(data, offset - dl * 3 - 4, dl * 3 + 4));
            offset += 4;
            if (pltAlpha) {
              wUi(data, offset, dl);
              offset += 4;
              wAs(data, offset, "tRNS");
              offset += 4;
              for (var i = 0; i < dl; i++) data[offset + i] = nimg.plte[i] >>> 24 & 255;
              offset += dl;
              wUi(data, offset, crc(data, offset - dl - 4, dl + 4));
              offset += 4;
            }
          }
          var fi = 0;
          for (var j = 0; j < nimg.frames.length; j++) {
            var fr = nimg.frames[j];
            if (anim) {
              wUi(data, offset, 26);
              offset += 4;
              wAs(data, offset, "fcTL");
              offset += 4;
              wUi(data, offset, fi++);
              offset += 4;
              wUi(data, offset, fr.rect.width);
              offset += 4;
              wUi(data, offset, fr.rect.height);
              offset += 4;
              wUi(data, offset, fr.rect.x);
              offset += 4;
              wUi(data, offset, fr.rect.y);
              offset += 4;
              wUs(data, offset, dels[j]);
              offset += 2;
              wUs(data, offset, 1e3);
              offset += 2;
              data[offset] = fr.dispose;
              offset++;
              data[offset] = fr.blend;
              offset++;
              wUi(data, offset, crc(data, offset - 30, 30));
              offset += 4;
            }
            var imgd = fr.cimg, dl = imgd.length;
            wUi(data, offset, dl + (j == 0 ? 0 : 4));
            offset += 4;
            var ioff = offset;
            wAs(data, offset, j == 0 ? "IDAT" : "fdAT");
            offset += 4;
            if (j != 0) {
              wUi(data, offset, fi++);
              offset += 4;
            }
            for (var i = 0; i < dl; i++) data[offset + i] = imgd[i];
            offset += dl;
            wUi(data, offset, crc(data, ioff, offset - ioff));
            offset += 4;
          }
          wUi(data, offset, 0);
          offset += 4;
          wAs(data, offset, "IEND");
          offset += 4;
          wUi(data, offset, crc(data, offset - 4, 4));
          offset += 4;
          return data.buffer;
        };
        UPNG2.encode.compressPNG = function(out, filter) {
          for (var i = 0; i < out.frames.length; i++) {
            var frm = out.frames[i], nw = frm.rect.width, nh = frm.rect.height;
            var fdata = new Uint8Array(nh * frm.bpl + nh);
            frm.cimg = UPNG2.encode._filterZero(frm.img, nh, frm.bpp, frm.bpl, fdata, filter);
          }
        };
        UPNG2.encode.compress = function(bufs, w, h, ps, prms) {
          var onlyBlend = prms[0], evenCrd = prms[1], forbidPrev = prms[2], minBits = prms[3], forbidPlte = prms[4];
          var ctype = 6, depth = 8, alphaAnd = 255;
          for (var j = 0; j < bufs.length; j++) {
            var img = new Uint8Array(bufs[j]), ilen = img.length;
            for (var i = 0; i < ilen; i += 4) alphaAnd &= img[i + 3];
          }
          var gotAlpha = alphaAnd != 255;
          var frms = UPNG2.encode.framize(bufs, w, h, onlyBlend, evenCrd, forbidPrev);
          var cmap = {}, plte = [], inds = [];
          if (ps != 0) {
            var nbufs = [];
            for (var i = 0; i < frms.length; i++) nbufs.push(frms[i].img.buffer);
            var abuf = UPNG2.encode.concatRGBA(nbufs), qres = UPNG2.quantize(abuf, ps);
            var cof = 0, bb = new Uint8Array(qres.abuf);
            for (var i = 0; i < frms.length; i++) {
              var ti = frms[i].img, bln = ti.length;
              inds.push(new Uint8Array(qres.inds.buffer, cof >> 2, bln >> 2));
              for (var j = 0; j < bln; j += 4) {
                ti[j] = bb[cof + j];
                ti[j + 1] = bb[cof + j + 1];
                ti[j + 2] = bb[cof + j + 2];
                ti[j + 3] = bb[cof + j + 3];
              }
              cof += bln;
            }
            for (var i = 0; i < qres.plte.length; i++) plte.push(qres.plte[i].est.rgba);
          } else {
            for (var j = 0; j < frms.length; j++) {
              var frm = frms[j], img32 = new Uint32Array(frm.img.buffer), nw = frm.rect.width, ilen = img32.length;
              var ind = new Uint8Array(ilen);
              inds.push(ind);
              for (var i = 0; i < ilen; i++) {
                var c = img32[i];
                if (i != 0 && c == img32[i - 1]) ind[i] = ind[i - 1];
                else if (i > nw && c == img32[i - nw]) ind[i] = ind[i - nw];
                else {
                  var cmc = cmap[c];
                  if (cmc == null) {
                    cmap[c] = cmc = plte.length;
                    plte.push(c);
                    if (plte.length >= 300) break;
                  }
                  ind[i] = cmc;
                }
              }
            }
          }
          var cc = plte.length;
          if (cc <= 256 && forbidPlte == false) {
            if (cc <= 2) depth = 1;
            else if (cc <= 4) depth = 2;
            else if (cc <= 16) depth = 4;
            else depth = 8;
            depth = Math.max(depth, minBits);
          }
          for (var j = 0; j < frms.length; j++) {
            var frm = frms[j], nx = frm.rect.x, ny = frm.rect.y, nw = frm.rect.width, nh = frm.rect.height;
            var cimg = frm.img, cimg32 = new Uint32Array(cimg.buffer);
            var bpl = 4 * nw, bpp = 4;
            if (cc <= 256 && forbidPlte == false) {
              bpl = Math.ceil(depth * nw / 8);
              var nimg = new Uint8Array(bpl * nh);
              var inj = inds[j];
              for (var y = 0; y < nh; y++) {
                var i = y * bpl, ii = y * nw;
                if (depth == 8) for (var x = 0; x < nw; x++) nimg[i + x] = inj[ii + x];
                else if (depth == 4) for (var x = 0; x < nw; x++) nimg[i + (x >> 1)] |= inj[ii + x] << 4 - (x & 1) * 4;
                else if (depth == 2) for (var x = 0; x < nw; x++) nimg[i + (x >> 2)] |= inj[ii + x] << 6 - (x & 3) * 2;
                else if (depth == 1) for (var x = 0; x < nw; x++) nimg[i + (x >> 3)] |= inj[ii + x] << 7 - (x & 7) * 1;
              }
              cimg = nimg;
              ctype = 3;
              bpp = 1;
            } else if (gotAlpha == false && frms.length == 1) {
              var nimg = new Uint8Array(nw * nh * 3), area = nw * nh;
              for (var i = 0; i < area; i++) {
                var ti = i * 3, qi = i * 4;
                nimg[ti] = cimg[qi];
                nimg[ti + 1] = cimg[qi + 1];
                nimg[ti + 2] = cimg[qi + 2];
              }
              cimg = nimg;
              ctype = 2;
              bpp = 3;
              bpl = 3 * nw;
            }
            frm.img = cimg;
            frm.bpl = bpl;
            frm.bpp = bpp;
          }
          return { ctype, depth, plte, frames: frms };
        };
        UPNG2.encode.framize = function(bufs, w, h, alwaysBlend, evenCrd, forbidPrev) {
          var frms = [];
          for (var j = 0; j < bufs.length; j++) {
            var cimg = new Uint8Array(bufs[j]), cimg32 = new Uint32Array(cimg.buffer);
            var nimg;
            var nx = 0, ny = 0, nw = w, nh = h, blend = alwaysBlend ? 1 : 0;
            if (j != 0) {
              var tlim = forbidPrev || alwaysBlend || j == 1 || frms[j - 2].dispose != 0 ? 1 : 2, tstp = 0, tarea = 1e9;
              for (var it = 0; it < tlim; it++) {
                var pimg = new Uint8Array(bufs[j - 1 - it]), p32 = new Uint32Array(bufs[j - 1 - it]);
                var mix = w, miy = h, max = -1, may = -1;
                for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) {
                  var i = y * w + x;
                  if (cimg32[i] != p32[i]) {
                    if (x < mix) mix = x;
                    if (x > max) max = x;
                    if (y < miy) miy = y;
                    if (y > may) may = y;
                  }
                }
                if (max == -1) mix = miy = max = may = 0;
                if (evenCrd) {
                  if ((mix & 1) == 1) mix--;
                  if ((miy & 1) == 1) miy--;
                }
                var sarea = (max - mix + 1) * (may - miy + 1);
                if (sarea < tarea) {
                  tarea = sarea;
                  tstp = it;
                  nx = mix;
                  ny = miy;
                  nw = max - mix + 1;
                  nh = may - miy + 1;
                }
              }
              var pimg = new Uint8Array(bufs[j - 1 - tstp]);
              if (tstp == 1) frms[j - 1].dispose = 2;
              nimg = new Uint8Array(nw * nh * 4);
              UPNG2._copyTile(pimg, w, h, nimg, nw, nh, -nx, -ny, 0);
              blend = UPNG2._copyTile(cimg, w, h, nimg, nw, nh, -nx, -ny, 3) ? 1 : 0;
              if (blend == 1) UPNG2.encode._prepareDiff(cimg, w, h, nimg, { x: nx, y: ny, width: nw, height: nh });
              else UPNG2._copyTile(cimg, w, h, nimg, nw, nh, -nx, -ny, 0);
            } else nimg = cimg.slice(0);
            frms.push({ rect: { x: nx, y: ny, width: nw, height: nh }, img: nimg, blend, dispose: 0 });
          }
          if (alwaysBlend) for (var j = 0; j < frms.length; j++) {
            var frm = frms[j];
            if (frm.blend == 1) continue;
            var r0 = frm.rect, r1 = frms[j - 1].rect;
            var miX = Math.min(r0.x, r1.x), miY = Math.min(r0.y, r1.y);
            var maX = Math.max(r0.x + r0.width, r1.x + r1.width), maY = Math.max(r0.y + r0.height, r1.y + r1.height);
            var r = { x: miX, y: miY, width: maX - miX, height: maY - miY };
            frms[j - 1].dispose = 1;
            if (j - 1 != 0)
              UPNG2.encode._updateFrame(bufs, w, h, frms, j - 1, r, evenCrd);
            UPNG2.encode._updateFrame(bufs, w, h, frms, j, r, evenCrd);
          }
          var area = 0;
          if (bufs.length != 1) for (var i = 0; i < frms.length; i++) {
            var frm = frms[i];
            area += frm.rect.width * frm.rect.height;
          }
          return frms;
        };
        UPNG2.encode._updateFrame = function(bufs, w, h, frms, i, r, evenCrd) {
          var U8 = Uint8Array, U32 = Uint32Array;
          var pimg = new U8(bufs[i - 1]), pimg32 = new U32(bufs[i - 1]), nimg = i + 1 < bufs.length ? new U8(bufs[i + 1]) : null;
          var cimg = new U8(bufs[i]), cimg32 = new U32(cimg.buffer);
          var mix = w, miy = h, max = -1, may = -1;
          for (var y = 0; y < r.height; y++) for (var x = 0; x < r.width; x++) {
            var cx = r.x + x, cy = r.y + y;
            var j = cy * w + cx, cc = cimg32[j];
            if (cc == 0 || frms[i - 1].dispose == 0 && pimg32[j] == cc && (nimg == null || nimg[j * 4 + 3] != 0)) {
            } else {
              if (cx < mix) mix = cx;
              if (cx > max) max = cx;
              if (cy < miy) miy = cy;
              if (cy > may) may = cy;
            }
          }
          if (max == -1) mix = miy = max = may = 0;
          if (evenCrd) {
            if ((mix & 1) == 1) mix--;
            if ((miy & 1) == 1) miy--;
          }
          r = { x: mix, y: miy, width: max - mix + 1, height: may - miy + 1 };
          var fr = frms[i];
          fr.rect = r;
          fr.blend = 1;
          fr.img = new Uint8Array(r.width * r.height * 4);
          if (frms[i - 1].dispose == 0) {
            UPNG2._copyTile(pimg, w, h, fr.img, r.width, r.height, -r.x, -r.y, 0);
            UPNG2.encode._prepareDiff(cimg, w, h, fr.img, r);
          } else
            UPNG2._copyTile(cimg, w, h, fr.img, r.width, r.height, -r.x, -r.y, 0);
        };
        UPNG2.encode._prepareDiff = function(cimg, w, h, nimg, rec) {
          UPNG2._copyTile(cimg, w, h, nimg, rec.width, rec.height, -rec.x, -rec.y, 2);
        };
        UPNG2.encode._filterZero = function(img, h, bpp, bpl, data, filter) {
          if (filter != -1) {
            for (var y = 0; y < h; y++) UPNG2.encode._filterLine(data, img, y, bpl, bpp, filter);
            return UZIP2["deflate"](data);
          }
          var fls = [];
          for (var t = 0; t < 5; t++) {
            if (h * bpl > 5e5 && (t == 1 || t == 2 || t == 3 || t == 4)) continue;
            for (var y = 0; y < h; y++) UPNG2.encode._filterLine(data, img, y, bpl, bpp, t);
            fls.push(UZIP2["deflate"](data));
            if (bpp == 1) break;
          }
          var ti, tsize = 1e9;
          for (var i = 0; i < fls.length; i++) if (fls[i].length < tsize) {
            ti = i;
            tsize = fls[i].length;
          }
          return fls[ti];
        };
        UPNG2.encode._filterLine = function(data, img, y, bpl, bpp, type) {
          var i = y * bpl, di = i + y, paeth = UPNG2.decode._paeth;
          data[di] = type;
          di++;
          if (type == 0) for (var x = 0; x < bpl; x++) data[di + x] = img[i + x];
          else if (type == 1) {
            for (var x = 0; x < bpp; x++) data[di + x] = img[i + x];
            for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x] - img[i + x - bpp] + 256 & 255;
          } else if (y == 0) {
            for (var x = 0; x < bpp; x++) data[di + x] = img[i + x];
            if (type == 2) for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x];
            if (type == 3) for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x] - (img[i + x - bpp] >> 1) + 256 & 255;
            if (type == 4) for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x] - paeth(img[i + x - bpp], 0, 0) + 256 & 255;
          } else {
            if (type == 2) {
              for (var x = 0; x < bpl; x++) data[di + x] = img[i + x] + 256 - img[i + x - bpl] & 255;
            }
            if (type == 3) {
              for (var x = 0; x < bpp; x++) data[di + x] = img[i + x] + 256 - (img[i + x - bpl] >> 1) & 255;
              for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x] + 256 - (img[i + x - bpl] + img[i + x - bpp] >> 1) & 255;
            }
            if (type == 4) {
              for (var x = 0; x < bpp; x++) data[di + x] = img[i + x] + 256 - paeth(0, img[i + x - bpl], 0) & 255;
              for (var x = bpp; x < bpl; x++) data[di + x] = img[i + x] + 256 - paeth(img[i + x - bpp], img[i + x - bpl], img[i + x - bpp - bpl]) & 255;
            }
          }
        };
        UPNG2.crc = {
          table: function() {
            var tab = new Uint32Array(256);
            for (var n = 0; n < 256; n++) {
              var c = n;
              for (var k = 0; k < 8; k++) {
                if (c & 1) c = 3988292384 ^ c >>> 1;
                else c = c >>> 1;
              }
              tab[n] = c;
            }
            return tab;
          }(),
          update: function(c, buf, off, len) {
            for (var i = 0; i < len; i++) c = UPNG2.crc.table[(c ^ buf[off + i]) & 255] ^ c >>> 8;
            return c;
          },
          crc: function(b, o, l) {
            return UPNG2.crc.update(4294967295, b, o, l) ^ 4294967295;
          }
        };
        UPNG2.quantize = function(abuf, ps) {
          var oimg = new Uint8Array(abuf), nimg = oimg.slice(0), nimg32 = new Uint32Array(nimg.buffer);
          var KD = UPNG2.quantize.getKDtree(nimg, ps);
          var root = KD[0], leafs = KD[1];
          var planeDst = UPNG2.quantize.planeDst;
          var sb = oimg, tb = nimg32, len = sb.length;
          var inds = new Uint8Array(oimg.length >> 2);
          for (var i = 0; i < len; i += 4) {
            var r = sb[i] * (1 / 255), g = sb[i + 1] * (1 / 255), b = sb[i + 2] * (1 / 255), a = sb[i + 3] * (1 / 255);
            var nd = UPNG2.quantize.getNearest(root, r, g, b, a);
            inds[i >> 2] = nd.ind;
            tb[i >> 2] = nd.est.rgba;
          }
          return { abuf: nimg.buffer, inds, plte: leafs };
        };
        UPNG2.quantize.getKDtree = function(nimg, ps, err) {
          if (err == null) err = 1e-4;
          var nimg32 = new Uint32Array(nimg.buffer);
          var root = { i0: 0, i1: nimg.length, bst: null, est: null, tdst: 0, left: null, right: null };
          root.bst = UPNG2.quantize.stats(nimg, root.i0, root.i1);
          root.est = UPNG2.quantize.estats(root.bst);
          var leafs = [root];
          while (leafs.length < ps) {
            var maxL = 0, mi = 0;
            for (var i = 0; i < leafs.length; i++) if (leafs[i].est.L > maxL) {
              maxL = leafs[i].est.L;
              mi = i;
            }
            if (maxL < err) break;
            var node = leafs[mi];
            var s0 = UPNG2.quantize.splitPixels(nimg, nimg32, node.i0, node.i1, node.est.e, node.est.eMq255);
            var s0wrong = node.i0 >= s0 || node.i1 <= s0;
            if (s0wrong) {
              node.est.L = 0;
              continue;
            }
            var ln = { i0: node.i0, i1: s0, bst: null, est: null, tdst: 0, left: null, right: null };
            ln.bst = UPNG2.quantize.stats(nimg, ln.i0, ln.i1);
            ln.est = UPNG2.quantize.estats(ln.bst);
            var rn = { i0: s0, i1: node.i1, bst: null, est: null, tdst: 0, left: null, right: null };
            rn.bst = { R: [], m: [], N: node.bst.N - ln.bst.N };
            for (var i = 0; i < 16; i++) rn.bst.R[i] = node.bst.R[i] - ln.bst.R[i];
            for (var i = 0; i < 4; i++) rn.bst.m[i] = node.bst.m[i] - ln.bst.m[i];
            rn.est = UPNG2.quantize.estats(rn.bst);
            node.left = ln;
            node.right = rn;
            leafs[mi] = ln;
            leafs.push(rn);
          }
          leafs.sort(function(a, b) {
            return b.bst.N - a.bst.N;
          });
          for (var i = 0; i < leafs.length; i++) leafs[i].ind = i;
          return [root, leafs];
        };
        UPNG2.quantize.getNearest = function(nd, r, g, b, a) {
          if (nd.left == null) {
            nd.tdst = UPNG2.quantize.dist(nd.est.q, r, g, b, a);
            return nd;
          }
          var planeDst = UPNG2.quantize.planeDst(nd.est, r, g, b, a);
          var node0 = nd.left, node1 = nd.right;
          if (planeDst > 0) {
            node0 = nd.right;
            node1 = nd.left;
          }
          var ln = UPNG2.quantize.getNearest(node0, r, g, b, a);
          if (ln.tdst <= planeDst * planeDst) return ln;
          var rn = UPNG2.quantize.getNearest(node1, r, g, b, a);
          return rn.tdst < ln.tdst ? rn : ln;
        };
        UPNG2.quantize.planeDst = function(est, r, g, b, a) {
          var e = est.e;
          return e[0] * r + e[1] * g + e[2] * b + e[3] * a - est.eMq;
        };
        UPNG2.quantize.dist = function(q, r, g, b, a) {
          var d0 = r - q[0], d1 = g - q[1], d2 = b - q[2], d3 = a - q[3];
          return d0 * d0 + d1 * d1 + d2 * d2 + d3 * d3;
        };
        UPNG2.quantize.splitPixels = function(nimg, nimg32, i0, i1, e, eMq) {
          var vecDot = UPNG2.quantize.vecDot;
          i1 -= 4;
          var shfs = 0;
          while (i0 < i1) {
            while (vecDot(nimg, i0, e) <= eMq) i0 += 4;
            while (vecDot(nimg, i1, e) > eMq) i1 -= 4;
            if (i0 >= i1) break;
            var t = nimg32[i0 >> 2];
            nimg32[i0 >> 2] = nimg32[i1 >> 2];
            nimg32[i1 >> 2] = t;
            i0 += 4;
            i1 -= 4;
          }
          while (vecDot(nimg, i0, e) > eMq) i0 -= 4;
          return i0 + 4;
        };
        UPNG2.quantize.vecDot = function(nimg, i, e) {
          return nimg[i] * e[0] + nimg[i + 1] * e[1] + nimg[i + 2] * e[2] + nimg[i + 3] * e[3];
        };
        UPNG2.quantize.stats = function(nimg, i0, i1) {
          var R = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
          var m = [0, 0, 0, 0];
          var N = i1 - i0 >> 2;
          for (var i = i0; i < i1; i += 4) {
            var r = nimg[i] * (1 / 255), g = nimg[i + 1] * (1 / 255), b = nimg[i + 2] * (1 / 255), a = nimg[i + 3] * (1 / 255);
            m[0] += r;
            m[1] += g;
            m[2] += b;
            m[3] += a;
            R[0] += r * r;
            R[1] += r * g;
            R[2] += r * b;
            R[3] += r * a;
            R[5] += g * g;
            R[6] += g * b;
            R[7] += g * a;
            R[10] += b * b;
            R[11] += b * a;
            R[15] += a * a;
          }
          R[4] = R[1];
          R[8] = R[2];
          R[9] = R[6];
          R[12] = R[3];
          R[13] = R[7];
          R[14] = R[11];
          return { R, m, N };
        };
        UPNG2.quantize.estats = function(stats) {
          var R = stats.R, m = stats.m, N = stats.N;
          var m0 = m[0], m1 = m[1], m2 = m[2], m3 = m[3], iN = N == 0 ? 0 : 1 / N;
          var Rj = [
            R[0] - m0 * m0 * iN,
            R[1] - m0 * m1 * iN,
            R[2] - m0 * m2 * iN,
            R[3] - m0 * m3 * iN,
            R[4] - m1 * m0 * iN,
            R[5] - m1 * m1 * iN,
            R[6] - m1 * m2 * iN,
            R[7] - m1 * m3 * iN,
            R[8] - m2 * m0 * iN,
            R[9] - m2 * m1 * iN,
            R[10] - m2 * m2 * iN,
            R[11] - m2 * m3 * iN,
            R[12] - m3 * m0 * iN,
            R[13] - m3 * m1 * iN,
            R[14] - m3 * m2 * iN,
            R[15] - m3 * m3 * iN
          ];
          var A = Rj, M = UPNG2.M4;
          var b = [0.5, 0.5, 0.5, 0.5], mi = 0, tmi = 0;
          if (N != 0)
            for (var i = 0; i < 10; i++) {
              b = M.multVec(A, b);
              tmi = Math.sqrt(M.dot(b, b));
              b = M.sml(1 / tmi, b);
              if (Math.abs(tmi - mi) < 1e-9) break;
              mi = tmi;
            }
          var q = [m0 * iN, m1 * iN, m2 * iN, m3 * iN];
          var eMq255 = M.dot(M.sml(255, q), b);
          return {
            Cov: Rj,
            q,
            e: b,
            L: mi,
            eMq255,
            eMq: M.dot(b, q),
            rgba: (Math.round(255 * q[3]) << 24 | Math.round(255 * q[2]) << 16 | Math.round(255 * q[1]) << 8 | Math.round(255 * q[0]) << 0) >>> 0
          };
        };
        UPNG2.M4 = {
          multVec: function(m, v) {
            return [
              m[0] * v[0] + m[1] * v[1] + m[2] * v[2] + m[3] * v[3],
              m[4] * v[0] + m[5] * v[1] + m[6] * v[2] + m[7] * v[3],
              m[8] * v[0] + m[9] * v[1] + m[10] * v[2] + m[11] * v[3],
              m[12] * v[0] + m[13] * v[1] + m[14] * v[2] + m[15] * v[3]
            ];
          },
          dot: function(x, y) {
            return x[0] * y[0] + x[1] * y[1] + x[2] * y[2] + x[3] * y[3];
          },
          sml: function(a, y) {
            return [a * y[0], a * y[1], a * y[2], a * y[3]];
          }
        };
        UPNG2.encode.concatRGBA = function(bufs) {
          var tlen = 0;
          for (var i = 0; i < bufs.length; i++) tlen += bufs[i].byteLength;
          var nimg = new Uint8Array(tlen), noff = 0;
          for (var i = 0; i < bufs.length; i++) {
            var img = new Uint8Array(bufs[i]), il = img.length;
            for (var j = 0; j < il; j += 4) {
              var r = img[j], g = img[j + 1], b = img[j + 2], a = img[j + 3];
              if (a == 0) r = g = b = 0;
              nimg[noff + j] = r;
              nimg[noff + j + 1] = g;
              nimg[noff + j + 2] = b;
              nimg[noff + j + 3] = a;
            }
            noff += il;
          }
          return nimg.buffer;
        };
      })(UPNG, UZIP);
    })();
  }
});

// ../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/png2icons.js
var require_png2icons = __commonJS({
  "../../../node_modules/.pnpm/png2icons@2.0.1/node_modules/png2icons/png2icons.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var icns_encoder_1 = require_icns_encoder();
    var Resize = require_resize3();
    var Resize4 = require_resize4();
    var UPNG = require_UPNG();
    var logFnc;
    function setLogger(logger) {
      logFnc = logger;
    }
    exports2.setLogger = setLogger;
    function LogMessage(message, ...optionalParams) {
      if (logFnc) {
        logFnc("png2icons", message, ...optionalParams);
      }
    }
    var MAX_COLORS = 256;
    exports2.NEAREST_NEIGHBOR = 0;
    exports2.BILINEAR = 1;
    exports2.BICUBIC = 2;
    exports2.BEZIER = 3;
    exports2.HERMITE = 4;
    exports2.BICUBIC2 = 5;
    function getRect(left, top, width, height) {
      return { Left: left, Top: top, Width: width, Height: height };
    }
    function getStretchedRect(src, dst) {
      let f;
      let tmp;
      const result = getRect(0, 0, 0, 0);
      if (src.Width / src.Height >= dst.Width / dst.Height) {
        f = dst.Width / src.Width;
        result.Left = 0;
        result.Width = dst.Width;
        tmp = Math.floor(src.Height * f);
        result.Top = Math.floor((dst.Height - tmp) / 2);
        result.Height = tmp;
      } else {
        f = dst.Height / src.Height;
        result.Top = 0;
        result.Height = dst.Height;
        tmp = Math.floor(src.Width * f);
        result.Left = Math.floor((dst.Width - tmp) / 2);
        result.Width = tmp;
      }
      return result;
    }
    var scaledImageCache = [];
    function getScaledImageData(srcImage, destRect, scalingAlgorithm) {
      if (srcImage.width === destRect.Width && srcImage.height === destRect.Height) {
        return srcImage.data;
      }
      for (const image of scaledImageCache) {
        if (destRect.Width === image.width && destRect.Height === image.height) {
          return image.data;
        }
      }
      const scaleResult = {
        data: new Uint8Array(destRect.Width * destRect.Height * 4),
        height: destRect.Height,
        width: destRect.Width
      };
      if (scalingAlgorithm === exports2.NEAREST_NEIGHBOR) {
        Resize.nearestNeighbor(srcImage, scaleResult);
      } else if (scalingAlgorithm === exports2.BILINEAR) {
        Resize.bilinearInterpolation(srcImage, scaleResult);
      } else if (scalingAlgorithm === exports2.BICUBIC) {
        Resize.bicubicInterpolation(srcImage, scaleResult);
      } else if (scalingAlgorithm === exports2.BEZIER) {
        Resize.bezierInterpolation(srcImage, scaleResult);
      } else if (scalingAlgorithm === exports2.HERMITE) {
        Resize.hermiteInterpolation(srcImage, scaleResult);
      } else if (scalingAlgorithm === exports2.BICUBIC2) {
        Resize4.bicubic(srcImage, scaleResult, destRect.Width / srcImage.width);
      } else {
        Resize.bicubicInterpolation(srcImage, scaleResult);
      }
      scaledImageCache.push(scaleResult);
      return scaleResult.data;
    }
    function getImageFromPNG(input) {
      try {
        const PNG = UPNG.decode(input);
        return {
          data: new Uint8Array(UPNG.toRGBA8(PNG)[0]),
          height: PNG.height,
          width: PNG.width
        };
      } catch (e) {
        LogMessage("Couldn't decode PNG:", e);
        return null;
      }
    }
    var scaledPNGImageCache = [];
    function getCachedPNG(rgba, width, height, numOfColors) {
      for (const image of scaledPNGImageCache) {
        if (image.Width === width && image.Height === height) {
          return image.Data;
        }
      }
      const result = UPNG.encode([rgba], width, height, numOfColors, [], true);
      scaledPNGImageCache.push({
        Data: result,
        Width: width,
        Height: height
      });
      return result;
    }
    var currentImage = null;
    function checkCache(image) {
      if (!image) {
        return;
      }
      if (!currentImage) {
        currentImage = image;
        return;
      }
      if (image.compare(currentImage) !== 0) {
        clearCache();
        currentImage = image;
      }
    }
    function clearCache() {
      scaledPNGImageCache.length = 0;
      scaledImageCache.length = 0;
      currentImage = null;
    }
    exports2.clearCache = clearCache;
    function scanImage(image, x, y, w, h, f) {
      for (let _y = y; _y < y + h; _y++) {
        for (let _x = x; _x < x + w; _x++) {
          const idx = image.width * _y + _x << 2;
          f.call(image, _x, _y, idx);
        }
      }
    }
    function blit(source, target, x, y) {
      x = Math.round(x);
      y = Math.round(y);
      scanImage(source, 0, 0, source.width, source.height, (sx, sy, idx) => {
        if (x + sx >= 0 && y + sy >= 0 && target.width - x - sx > 0 && target.height - y - sy > 0) {
          const destIdx = target.width * (y + sy) + (x + sx) << 2;
          target.data[destIdx] = source.data[idx];
          target.data[destIdx + 1] = source.data[idx + 1];
          target.data[destIdx + 2] = source.data[idx + 2];
          target.data[destIdx + 3] = source.data[idx + 3];
        }
      });
    }
    function getQuadraticImage(image) {
      if (image.height === image.width) {
        return image;
      }
      let edgeLength;
      let blitX;
      let blitY;
      if (image.height > image.width) {
        edgeLength = image.height;
        blitX = (image.height - image.width) / 2;
        blitY = 0;
      } else {
        edgeLength = image.width;
        blitX = 0;
        blitY = (image.width - image.height) / 2;
      }
      const result = {
        data: new Uint8Array(edgeLength * edgeLength * 4),
        height: edgeLength,
        width: edgeLength
      };
      blit(image, result, blitX, blitY);
      return result;
    }
    function getImageChannel(image, bpp, channelIndex) {
      const channel = Buffer.alloc(image.length / bpp);
      const length = image.length;
      let outPos = 0;
      for (let i = channelIndex; i < length; i = i + 4) {
        channel.writeUInt8(image[i], outPos++);
      }
      return channel;
    }
    var IconFormat;
    (function(IconFormat2) {
      IconFormat2[IconFormat2["PNG"] = 0] = "PNG";
      IconFormat2[IconFormat2["PackBitsARGB"] = 1] = "PackBitsARGB";
      IconFormat2[IconFormat2["PackBitsRGB"] = 2] = "PackBitsRGB";
      IconFormat2[IconFormat2["Alpha"] = 3] = "Alpha";
    })(IconFormat || (IconFormat = {}));
    function encodeIconWithPackBits(image, withAlphaChannel) {
      const R = icns_encoder_1.encode(getImageChannel(image, 4, 0));
      const G = icns_encoder_1.encode(getImageChannel(image, 4, 1));
      const B = icns_encoder_1.encode(getImageChannel(image, 4, 2));
      if (withAlphaChannel) {
        const header = Buffer.alloc(4);
        header.write("ARGB", 0, 4, "ascii");
        const A = icns_encoder_1.encode(getImageChannel(image, 4, 3));
        return Buffer.concat([header, A, R, G, B], header.length + A.length + R.length + G.length + B.length);
      } else {
        return Buffer.concat([R, G, B], R.length + G.length + B.length);
      }
    }
    function appendIcnsChunk(chunkParams, srcImage, scalingAlgorithm, numOfColors, outBuffer) {
      try {
        const icnsChunkRect = getStretchedRect(getRect(0, 0, srcImage.width, srcImage.height), getRect(0, 0, chunkParams.Size, chunkParams.Size));
        const scaledRawData = getScaledImageData(srcImage, icnsChunkRect, scalingAlgorithm);
        let encodedIcon;
        const iconHeader = Buffer.alloc(8);
        iconHeader.write(chunkParams.OSType, 0);
        switch (chunkParams.Format) {
          case IconFormat.PNG:
            encodedIcon = getCachedPNG(scaledRawData.buffer, icnsChunkRect.Width, icnsChunkRect.Height, numOfColors);
            break;
          case IconFormat.PackBitsARGB:
            encodedIcon = encodeIconWithPackBits(Buffer.from(scaledRawData.buffer), true);
            break;
          case IconFormat.PackBitsRGB:
            encodedIcon = encodeIconWithPackBits(Buffer.from(scaledRawData.buffer), false);
            break;
          case IconFormat.Alpha:
            encodedIcon = getImageChannel(Buffer.from(scaledRawData.buffer), 4, 3);
            break;
          default:
            throw new Error("Unknown format for icon (must be PNG, PackBitsARGB, PackBitsRGB or Alpha)");
        }
        iconHeader.writeUInt32BE(encodedIcon.byteLength + 8, 4);
        return Buffer.concat([outBuffer, iconHeader, Buffer.from(encodedIcon)], outBuffer.length + iconHeader.length + encodedIcon.byteLength);
      } catch (e) {
        LogMessage("Could't append ICNS chunk", e);
        return null;
      }
    }
    function createICNS2(input, scalingAlgorithm, numOfColors) {
      checkCache(input);
      let inputImage = getImageFromPNG(input);
      if (!inputImage) {
        return null;
      }
      const srcImage = getQuadraticImage(inputImage);
      inputImage = null;
      const icnsChunks = [
        // Note: Strange enough, but the order of the different chunks in the output file
        // seems to be relevant if ic04 and ic05 packbits icons are used. For example, if
        // they are placed at the end of the file the Finder and the Preview app are unable
        // to display them correctly. The position doesn't seem to have an impact for PNG
        // encoded icons, only for those two icons. ic04 and ic05 are supported on versions
        // 10.14 and newer but they don't seem to have a negative impact on older versions,
        // they are simply ignored. Nevertheless png2icons uses is32 and il32 for better
        // support on older versions.
        // The following order is the same of that created by iconutil on 10.14.
        { OSType: "ic12", Format: IconFormat.PNG, Size: 64, Info: "32x32@2  " },
        { OSType: "ic07", Format: IconFormat.PNG, Size: 128, Info: "128x128  " },
        { OSType: "ic13", Format: IconFormat.PNG, Size: 256, Info: "128x128@2" },
        { OSType: "ic08", Format: IconFormat.PNG, Size: 256, Info: "256x256  " },
        // { OSType: "ic04", Format: IconFormat.PackBitsARGB, Size: 16,   Info: "16x16    " },
        { OSType: "ic14", Format: IconFormat.PNG, Size: 512, Info: "256x256@2" },
        { OSType: "ic09", Format: IconFormat.PNG, Size: 512, Info: "512x512  " },
        // { OSType: "ic05", Format: IconFormat.PackBitsARGB, Size: 32,   Info: "32x32    " },
        { OSType: "ic10", Format: IconFormat.PNG, Size: 1024, Info: "512x512@2" },
        { OSType: "ic11", Format: IconFormat.PNG, Size: 32, Info: "16x16@2  " },
        // Important note:
        // The types il32 and is32 have to be Packbits encoded in RGB and they *need*
        // a *corresponding separate mask icon entry*. This mask contains an *uncompressed*
        // alpha channel with the same image dimensions.
        // Finding information on this was nearly impossible, the only source which finally
        // led to the solution was this documentation from the stone ages:
        // https://books.google.de/books?id=MTNUf464tHwC&pg=PA434&lpg=PA434&dq=mac+is32+icns&source=bl&ots=0fZ2g1qiia&sig=ACfU3U0uEMDeLkjeRL6CgD9_G_bPHasmEw&hl=de&sa=X&ved=2ahUKEwi_pYH0-5PjAhUGZ1AKHRx7CWMQ6AEwBnoECAkQAQ#v=onepage&q=mac%20is32%20icns&f=false
        { OSType: "il32", Format: IconFormat.PackBitsRGB, Size: 32, Info: "32x32    " },
        { OSType: "l8mk", Format: IconFormat.Alpha, Size: 32, Info: "32x32    " },
        { OSType: "is32", Format: IconFormat.PackBitsRGB, Size: 16, Info: "16x16    " },
        { OSType: "s8mk", Format: IconFormat.Alpha, Size: 16, Info: "16x16    " }
      ];
      let outBuffer = Buffer.alloc(8, 0);
      outBuffer.write("icns", 0);
      const nOfColors = numOfColors < 0 ? 0 : numOfColors > MAX_COLORS ? MAX_COLORS : numOfColors;
      for (const chunkParams of icnsChunks) {
        outBuffer = appendIcnsChunk(chunkParams, srcImage, scalingAlgorithm, nOfColors, outBuffer);
        if (!outBuffer) {
          return null;
        }
        LogMessage(`wrote type ${chunkParams.OSType} for size ${chunkParams.Info} with ${chunkParams.Size} pixels`);
      }
      outBuffer.writeUInt32BE(outBuffer.length, 4);
      LogMessage("done");
      return outBuffer;
    }
    exports2.createICNS = createICNS2;
    var BITMAPINFOHEADERLENGTH = 40;
    function getICONDIR(numOfImages) {
      const iconDir = Buffer.alloc(6);
      iconDir.writeUInt16LE(0, 0);
      iconDir.writeUInt16LE(1, 2);
      iconDir.writeUInt16LE(numOfImages, 4);
      return iconDir;
    }
    function getICONDIRENTRY(imageSize, width, height, offset) {
      const iconDirEntry = Buffer.alloc(16);
      width = width >= 256 ? 0 : width;
      height = height >= 256 ? 0 : height;
      iconDirEntry.writeUInt8(width, 0);
      iconDirEntry.writeUInt8(height, 1);
      iconDirEntry.writeUInt8(0, 2);
      iconDirEntry.writeUInt8(0, 3);
      iconDirEntry.writeUInt16LE(1, 4);
      iconDirEntry.writeUInt16LE(32, 6);
      iconDirEntry.writeUInt32LE(imageSize, 8);
      iconDirEntry.writeUInt32LE(offset, 12);
      return iconDirEntry;
    }
    function getMaskSize(bitmapWidth, bitmapHeight) {
      return (bitmapWidth + (bitmapWidth % 32 ? 32 - bitmapWidth % 32 : 0)) * bitmapHeight / 8;
    }
    function getBITMAPINFOHEADER(image) {
      const buffer = Buffer.alloc(BITMAPINFOHEADERLENGTH);
      const imageSize = image.data.length + getMaskSize(image.width, image.height);
      buffer.writeUInt32LE(40, 0);
      buffer.writeInt32LE(image.width, 4);
      buffer.writeInt32LE(image.height * 2, 8);
      buffer.writeUInt16LE(1, 12);
      buffer.writeUInt16LE(32, 14);
      buffer.writeUInt32LE(0, 16);
      buffer.writeUInt32LE(imageSize, 20);
      buffer.writeInt32LE(3780, 24);
      buffer.writeInt32LE(3780, 28);
      buffer.writeUInt32LE(0, 32);
      buffer.writeUInt32LE(0, 36);
      return buffer;
    }
    function getDIB(image) {
      const bitmap = Buffer.from(image.data);
      const DIB = Buffer.alloc(image.data.length);
      const maskSize = getMaskSize(image.width, image.height);
      let maskBits = [];
      const bytesPerPixel = 4;
      const columns = image.width * bytesPerPixel;
      const rows = image.height * columns;
      const end = rows - columns;
      for (let row = 0; row < rows; row += columns) {
        for (let col = 0; col < columns; col += bytesPerPixel) {
          let pos = row + col;
          const r = bitmap.readUInt8(pos);
          const g = bitmap.readUInt8(pos + 1);
          const b = bitmap.readUInt8(pos + 2);
          const a = bitmap.readUInt8(pos + 3);
          pos = end - row + col;
          DIB.writeUInt8(b, pos);
          DIB.writeUInt8(g, pos + 1);
          DIB.writeUInt8(r, pos + 2);
          DIB.writeUInt8(a, pos + 3);
          maskBits.push(bitmap[pos + 3] === 0 ? 1 : 0);
        }
        const padding = maskBits.length % 32 ? 32 - maskBits.length % 32 : 0;
        maskBits = maskBits.concat(Array(padding).fill(0));
      }
      const mask = [];
      for (let i = 0; i < maskBits.length; i += 8) {
        const n = parseInt(maskBits.slice(i, i + 8).join(""), 2);
        const buf = Buffer.alloc(1);
        buf.writeUInt8(n, 0);
        mask.push(buf);
      }
      return Buffer.concat([DIB, Buffer.concat(mask, maskSize)]);
    }
    function createICO2(input, scalingAlgorithm, numOfColors, PNG, forWinExe) {
      checkCache(input);
      let inputImage = getImageFromPNG(input);
      if (!inputImage) {
        return null;
      }
      const srcImage = getQuadraticImage(inputImage);
      inputImage = null;
      const icoChunkSizes = [256, 128, 96, 72, 64, 48, 32, 24, 16];
      const icoDirectory = [];
      icoDirectory.push(getICONDIR(icoChunkSizes.length));
      let totalLength = icoDirectory[0].length;
      const icoChunkImages = [];
      let chunkOffset = icoDirectory[0].length + icoChunkSizes.length * 16;
      for (const icoChunkSize of icoChunkSizes) {
        const icoChunkRect = getStretchedRect(getRect(0, 0, srcImage.width, srcImage.height), getRect(0, 0, icoChunkSize, icoChunkSize));
        const scaledRawImage = {
          data: getScaledImageData(srcImage, icoChunkRect, scalingAlgorithm),
          height: icoChunkRect.Height,
          width: icoChunkRect.Width
        };
        let formatInfo;
        if (PNG || forWinExe && [256, 128, 96, 72, 64].indexOf(icoChunkRect.Height) !== -1) {
          formatInfo = "png";
          const encodedIcon = getCachedPNG(scaledRawImage.data.buffer, scaledRawImage.width, scaledRawImage.height, numOfColors < 0 ? 0 : numOfColors > MAX_COLORS ? MAX_COLORS : numOfColors);
          const iconDirEntry = getICONDIRENTRY(encodedIcon.byteLength, scaledRawImage.width, scaledRawImage.height, chunkOffset);
          icoDirectory.push(iconDirEntry);
          icoChunkImages.push(Buffer.from(encodedIcon));
          totalLength += iconDirEntry.length + encodedIcon.byteLength;
          chunkOffset += encodedIcon.byteLength;
        } else {
          formatInfo = "bmp";
          const iconDirEntry = getICONDIRENTRY(scaledRawImage.data.length + getMaskSize(scaledRawImage.width, scaledRawImage.height) + BITMAPINFOHEADERLENGTH, scaledRawImage.width, scaledRawImage.height, chunkOffset);
          icoDirectory.push(iconDirEntry);
          const bmpInfoHeader = getBITMAPINFOHEADER(scaledRawImage);
          const DIB = getDIB(scaledRawImage);
          icoChunkImages.push(bmpInfoHeader, DIB);
          totalLength += iconDirEntry.length + bmpInfoHeader.length + DIB.length;
          chunkOffset += bmpInfoHeader.length + DIB.length;
        }
        LogMessage(`wrote ${formatInfo} icon for size ${icoChunkSize}`);
      }
      LogMessage(`done`);
      return Buffer.concat(icoDirectory.concat(icoChunkImages), totalLength);
    }
    exports2.createICO = createICO2;
  }
});

// src/cli.ts
var import_fs5 = require("fs");
var import_path5 = require("path");

// src/svg.ts
var import_fs = require("fs");
var import_path = require("path");
var resvgWasm = require_resvg_wasm();
var initialized = false;
async function ensureInit() {
  if (initialized) return;
  const wasmPath = (0, import_path.join)(__dirname, "resvg.wasm");
  const wasmBuffer = (0, import_fs.readFileSync)(wasmPath);
  await resvgWasm.initWasm(wasmBuffer);
  initialized = true;
}
async function svgToPng(svgData, targetWidth) {
  await ensureInit();
  const resvg = new resvgWasm.Resvg(svgData, {
    fitTo: { mode: "width", value: targetWidth }
  });
  const rendered = resvg.render();
  return Buffer.from(rendered.asPng());
}

// src/icns.ts
var import_fs2 = require("fs");
var import_path2 = require("path");
var png2icons = __toESM(require_png2icons());
function createIcns(inputBuffer, outputDir) {
  const icnsBuffer = png2icons.createICNS(inputBuffer, png2icons.BILINEAR, 0);
  if (!icnsBuffer) throw new Error("png2icons failed to create ICNS \u2014 ensure input is a valid PNG (1024\xD71024 recommended)");
  (0, import_fs2.writeFileSync)((0, import_path2.join)(outputDir, "icon.icns"), icnsBuffer);
}

// src/ico.ts
var import_fs3 = require("fs");
var import_path3 = require("path");
var png2icons2 = __toESM(require_png2icons());
function createIco(inputBuffer, outputDir) {
  const icoBuffer = png2icons2.createICO(inputBuffer, png2icons2.BILINEAR, 0, false);
  if (!icoBuffer) throw new Error("png2icons failed to create ICO \u2014 ensure input is a valid PNG (512\xD7512 or larger recommended)");
  (0, import_fs3.writeFileSync)((0, import_path3.join)(outputDir, "icon.ico"), icoBuffer);
}

// src/linux.ts
var import_fs4 = require("fs");
var import_path4 = require("path");
var LINUX_SIZES = [16, 24, 32, 48, 64, 128, 256, 512];
async function createLinuxSet(inputBuffer, outputDir) {
  const b64 = inputBuffer.toString("base64");
  for (const size of LINUX_SIZES) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${size}" height="${size}"><image href="data:image/png;base64,${b64}" width="${size}" height="${size}"/></svg>`;
    const resized = await svgToPng(Buffer.from(svg), size);
    (0, import_fs4.writeFileSync)((0, import_path4.join)(outputDir, `${size}x${size}.png`), resized);
  }
}

// src/icns-input.ts
var PREFERRED_TYPES = ["ic10", "ic09", "ic14", "ic08", "ic13"];
var SKIP_TYPES = /* @__PURE__ */ new Set(["info", "TOC ", "icnV", "name"]);
var PNG_MAGIC = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
function isPng(data) {
  return data.length >= 8 && data.subarray(0, 8).equals(PNG_MAGIC);
}
function extractLargestPngFromIcns(data) {
  const typeMap = /* @__PURE__ */ new Map();
  let offset = 8;
  while (offset < data.length) {
    if (offset + 8 > data.length) break;
    const ostype = data.toString("ascii", offset, offset + 4);
    const entryLen = data.readUInt32BE(offset + 4);
    if (entryLen < 8) break;
    if (!SKIP_TYPES.has(ostype)) {
      typeMap.set(ostype, { offset: offset + 8, length: entryLen - 8 });
    }
    offset += entryLen;
  }
  for (const t of PREFERRED_TYPES) {
    const entry = typeMap.get(t);
    if (entry) {
      const payload = data.subarray(entry.offset, entry.offset + entry.length);
      if (isPng(payload)) return payload;
    }
  }
  return null;
}

// src/cli.ts
function parseArgs(argv) {
  const args = {};
  for (const arg of argv) {
    const m = arg.match(/^--([^=]+)=(.*)$/);
    if (m) args[m[1]] = m[2];
  }
  return args;
}
var VALID_FORMATS = ["icns", "ico", "set"];
var SVG_RASTER_WIDTH = 1024;
async function main() {
  const args = parseArgs(process.argv.slice(2));
  const input = args["input"];
  const format = args["format"];
  const outDir = args["out"];
  if (!input || !format || !outDir) {
    console.error("Usage: node icon-tool.js --input=<path> --format=<icns|ico|set> --out=<dir>");
    process.exit(1);
  }
  if (!VALID_FORMATS.includes(format)) {
    console.error(`Invalid format "${format}". Valid formats: ${VALID_FORMATS.join(", ")}`);
    process.exit(1);
  }
  if (!(0, import_fs5.existsSync)(input)) {
    console.error(`Input file not found: ${input}`);
    process.exit(1);
  }
  (0, import_fs5.mkdirSync)(outDir, { recursive: true });
  const ext = (0, import_path5.extname)(input).toLowerCase();
  let pngBuffer;
  if (ext === ".svg") {
    const svgBuffer = (0, import_fs5.readFileSync)(input);
    pngBuffer = await svgToPng(svgBuffer, SVG_RASTER_WIDTH);
  } else if (ext === ".png") {
    pngBuffer = (0, import_fs5.readFileSync)(input);
  } else if (ext === ".icns") {
    const icnsBuffer = (0, import_fs5.readFileSync)(input);
    const extracted = extractLargestPngFromIcns(icnsBuffer);
    if (!extracted) {
      console.error("Could not extract a PNG frame from ICNS file");
      process.exit(1);
    }
    pngBuffer = extracted;
  } else {
    console.error(`Unsupported input format "${ext}". Supported: .png, .svg, .icns`);
    process.exit(1);
  }
  switch (format) {
    case "icns":
      createIcns(pngBuffer, outDir);
      break;
    case "ico":
      createIco(pngBuffer, outDir);
      break;
    case "set":
      await createLinuxSet(pngBuffer, outDir);
      break;
  }
  console.log(`Done: ${format} \u2192 ${outDir}`);
}
main().catch((err) => {
  console.error("Error:", err.message || String(err));
  process.exit(1);
});
